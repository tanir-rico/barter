# Barter App

Мобильное и web-приложение для обмена книгами, вещами и услугами.  
Проект построен на Expo + React Native + Supabase и включает real-time чат, сделки, отзывы, жалобы и админ-панель.

## Что реализовано

- Авторизация и регистрация пользователей через Supabase Auth.
- Профили пользователей: имя, username, аватар, телефон, bio.
- Каталог объявлений:
  - создание, редактирование, удаление;
  - типы: `book`, `item`, `service`;
  - фото объявлений (Supabase Storage);
  - фильтры и поиск.
- Чаты между пользователями:
  - создание комнаты на основе объявления;
  - отправка текста и изображений;
  - real-time обновления сообщений.
- Система сделок:
  - предложение сделки;
  - подтверждение / отмена;
  - переход к оставлению отзыва после подтверждения.
- Отзывы:
  - оценка 1-5;
  - текстовый комментарий;
  - отображение рейтинга пользователя.
- Жалобы (reports):
  - жалоба на объявление или пользователя;
  - статус жалобы (`new`, `in_review`, `resolved`, `rejected`).
- Админ-панель:
  - модерация пользователей, объявлений и жалоб;
  - фильтры по статусам;
  - действия (бан, разбан, блок/удаление объявления, обработка жалоб).
- Локализация интерфейса: English / Русский / Кыргызча.
- RLS-политики Supabase для защиты данных и ограничений доступа.

## Архитектура проекта

- `app/` — экраны приложения (Expo Router).
- `components/` — переиспользуемые UI-компоненты.
- `context/` — глобальные контексты (`DataContext`, `ThemeContext`, `LanguageContext`).
- `lib/` — типы, Supabase-клиент, storage/API-слой.
- `supabase/` — SQL-скрипты схемы и политик:
  - `supabase/profiles.sql`
  - `supabase/marketplace.sql`

## Основные сущности БД

- `profiles`
- `listings`
- `chat_rooms`
- `messages`
- `deals`
- `reviews`
- `complaints`

Дополнительно используются storage buckets:

- `avatars`
- `listing-images`
- `chat-images`

## Технологии

- Expo / React Native / Expo Router
- TypeScript
- Supabase (Auth, Postgres, Realtime, Storage)
- AsyncStorage
- Expo Image / Image Picker / Haptics

## Требования

- Node.js 18+
- npm
- Supabase проект (URL + anon key)

## Настройка

1. Установите зависимости:

```bash
npm install
```

2. Создайте `.env` на основе `.env.example`:

```env
EXPO_PUBLIC_SUPABASE_URL=https://your-project-ref.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

3. В Supabase SQL Editor выполните:
- `supabase/profiles.sql`
- `supabase/marketplace.sql`

4. Перезапустите Expo после изменения `.env`.

## Запуск проекта

### Универсальный запуск (Expo)

```bash
npm start
```

Дальше в терминале:
- `w` — web
- `a` — Android
- `i` — iOS (macOS)

### Прямой запуск web

```bash
npx expo start --web
```

### Линт

```bash
npm run lint
```

## Полезные примечания

- Если видите ошибку вида `Invalid API key`:
  - проверьте `EXPO_PUBLIC_SUPABASE_ANON_KEY` в `.env`;
  - убедитесь, что ключ относится к вашему Supabase-проекту.
- Если после SQL-изменений появляется ошибка schema cache (`column ... does not exist`):
  - убедитесь, что миграция применена в правильном проекте;
  - перезапустите приложение.
- Админ-права задаются в `profiles.is_admin = true`.

## Быстрый обзор бизнес-логики

- Забаненный пользователь не должен создавать объявления, писать в чат и инициировать сделки.
- Удаленные/скрытые объекты не должны попадать в публичные выборки.
- Все чувствительные операции защищены RLS и проверкой текущего `auth.uid()`.

## Скриншоты и код для отчета

Для курсовой/диплома можно использовать:
- скриншоты экранов приложения;
- скриншоты ключевых участков кода (`context`, `lib/storage.ts`, SQL в `supabase/`);
- ER-структуру таблиц и RLS-политики как отдельные иллюстрации.

