import React, { useCallback, useMemo, useState } from 'react';
import {
  View, Text, FlatList, Pressable, StyleSheet, Platform, ActivityIndicator, TextInput, Alert, ScrollView, useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import { useLanguage } from '@/context/LanguageContext';
import type { ListingStatus, UserStatus } from '@/lib/types';
import * as store from '@/lib/storage';

type AdminTab = 'users' | 'listings' | 'complaints';

const USER_STATUS_FILTERS: Array<UserStatus | 'all'> = ['all', 'active', 'banned', 'deleted'];
const LISTING_STATUS_FILTERS: Array<ListingStatus | 'all'> = ['all', 'active', 'closed', 'blocked', 'deleted'];
const COMPLAINT_STATUS_FILTERS = ['all', 'new', 'in_review', 'resolved', 'rejected'] as const;

export default function AdminScreen() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { width } = useWindowDimensions();
  const { currentUser } = useData();
  const { t } = useLanguage();
  const isAdmin = Boolean(currentUser?.isAdmin);

  const [tab, setTab] = useState<AdminTab>('complaints');
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  const [users, setUsers] = useState<store.AdminUserDetails[]>([]);
  const [listings, setListings] = useState<store.AdminListingDetails[]>([]);
  const [complaints, setComplaints] = useState<store.AdminComplaintItem[]>([]);

  const [userStatusFilter, setUserStatusFilter] = useState<UserStatus | 'all'>('all');
  const [listingStatusFilter, setListingStatusFilter] = useState<ListingStatus | 'all'>('all');
  const [complaintStatusFilter, setComplaintStatusFilter] = useState<typeof COMPLAINT_STATUS_FILTERS[number]>('all');

  const loadUsers = useCallback(async () => {
    const brief = await store.getAdminUsers({ status: userStatusFilter, search });
    const details = await Promise.all(brief.map((u) => store.getAdminUserDetails(u.id)));
    setUsers(details.filter((x): x is store.AdminUserDetails => Boolean(x)));
  }, [userStatusFilter, search]);

  const loadListings = useCallback(async () => {
    const brief = await store.getAdminListings({ status: listingStatusFilter, search });
    const details = await Promise.all(brief.map((l) => store.getAdminListingDetails(l.id)));
    setListings(details.filter((x): x is store.AdminListingDetails => Boolean(x)));
  }, [listingStatusFilter, search]);

  const loadComplaints = useCallback(async () => {
    const all = await store.getAdminComplaints();
    setComplaints(complaintStatusFilter === 'all'
      ? all
      : all.filter((item) => item.complaint.status === complaintStatusFilter));
  }, [complaintStatusFilter]);

  const loadData = useCallback(async () => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      if (tab === 'users') await loadUsers();
      if (tab === 'listings') await loadListings();
      if (tab === 'complaints') await loadComplaints();
    } catch (e) {
      console.error(e);
      Alert.alert(t('error'), e instanceof Error ? e.message : t('admin_failed_load_data'));
    } finally {
      setLoading(false);
    }
  }, [isAdmin, tab, loadUsers, loadListings, loadComplaints, t]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const runAction = useCallback(async (busyKey: string, action: () => Promise<void>) => {
    setBusyId(busyKey);
    try {
      await action();
      await loadData();
    } catch (e) {
      Alert.alert(t('error'), e instanceof Error ? e.message : t('admin_action_failed'));
    } finally {
      setBusyId(null);
    }
  }, [loadData, t]);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const isSmallScreen = width < 390;
  const chipHeight = isSmallScreen ? 36 : 40;
  const statusColor = useMemo(() => ({
    all: colors.tint,
    active: colors.success,
    banned: colors.danger,
    deleted: colors.textSecondary,
    blocked: colors.danger,
    closed: colors.accent,
    new: colors.danger,
    in_review: colors.accent,
    resolved: colors.success,
    rejected: colors.textSecondary,
  }), [colors]);
  const getComplaintReasonLabel = useCallback((reason: string) => {
    const normalized = reason.trim().toLowerCase();
    const reasonMap: Record<string, string> = {
      'spam or scam': t('reason_spam'),
      'inappropriate content': t('reason_inappropriate'),
      harassment: t('reason_harassment'),
      'misleading information': t('reason_misleading'),
      'stolen goods': t('reason_stolen'),
      other: t('reason_other'),
    };
    return reasonMap[normalized] || reason;
  }, [t]);

  const getTargetTypeLabel = useCallback((targetType: 'listing' | 'user') => {
    return targetType === 'listing' ? t('target_type_listing') : t('target_type_user');
  }, [t]);

  if (!isAdmin) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Ionicons name="lock-closed-outline" size={38} color={colors.textSecondary} />
        <Text style={[styles.deniedText, { color: colors.textSecondary }]}>{t('admin_access_only')}</Text>
      </View>
    );
  }

  const renderUsers = () => (
    <FlatList
      data={users}
      keyExtractor={(item) => item.user.id}
      contentContainerStyle={styles.list}
      renderItem={({ item }) => {
        const u = item.user;
        const isBusy = busyId === `user:${u.id}`;
        return (
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.rowBetween}>
              <Text style={[styles.title, { color: colors.text }]}>{u.displayName} (@{u.username})</Text>
              <View style={[styles.badge, { backgroundColor: `${statusColor[u.status]}22` }]}>
                <Text style={[styles.badgeText, { color: statusColor[u.status] }]}>{t(`status_${u.status}`)}</Text>
              </View>
            </View>
            <Text style={[styles.meta, { color: colors.textSecondary }]}>{t('id_label')}: {u.id}</Text>
            <Text style={[styles.meta, { color: colors.textSecondary }]}>
              {t('listings_label')}: {item.listings.length} | {t('complaints_label')}: {item.complaintsCount} | {t('rating_label')}: {item.rating.average.toFixed(1)} ({item.rating.count}) | {t('active_deals_label')}: {item.activeDeals}
            </Text>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.actionsRow}>
              <Pressable
                disabled={isBusy || u.status === 'banned'}
                onPress={() => runAction(`user:${u.id}`, () => store.adminSetUserStatus(u.id, 'banned', 'Moderation action'))}
                style={[styles.actionBtn, { backgroundColor: `${colors.danger}22` }]}
              >
                <Text style={[styles.actionText, { color: colors.danger }]}>{t('action_ban')}</Text>
              </Pressable>
              <Pressable
                disabled={isBusy || u.status === 'active'}
                onPress={() => runAction(`user:${u.id}`, () => store.adminSetUserStatus(u.id, 'active', 'Ban removed'))}
                style={[styles.actionBtn, { backgroundColor: `${colors.success}22` }]}
              >
                <Text style={[styles.actionText, { color: colors.success }]}>{t('action_unban')}</Text>
              </Pressable>
            </ScrollView>
            {isBusy && <ActivityIndicator size="small" color={colors.tint} />}
          </View>
        );
      }}
    />
  );

  const renderListings = () => (
    <FlatList
      data={listings}
      keyExtractor={(item) => item.listing.id}
      contentContainerStyle={styles.list}
      renderItem={({ item }) => {
        const l = item.listing;
        const isBusy = busyId === `listing:${l.id}`;
        return (
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.rowBetween}>
              <Text style={[styles.title, { color: colors.text }]}>{l.title}</Text>
              <View style={[styles.badge, { backgroundColor: `${statusColor[l.status]}22` }]}>
                <Text style={[styles.badgeText, { color: statusColor[l.status] }]}>{t(`status_${l.status}`)}</Text>
              </View>
            </View>
            <Text style={[styles.meta, { color: colors.textSecondary }]}>{t('author_label')}: {item.author?.displayName || l.authorId}</Text>
            <Text style={[styles.meta, { color: colors.textSecondary }]}>
              {t('created_label')}: {new Date(l.createdAt).toLocaleString()} | {t('complaints_label')}: {item.complaintsCount}
            </Text>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.actionsRow}>
              <Pressable
                disabled={isBusy || l.status === 'blocked'}
                onPress={() => runAction(`listing:${l.id}`, () => store.adminSetListingStatus(l.id, 'blocked', 'Blocked by admin'))}
                style={[styles.actionBtn, { backgroundColor: `${colors.danger}22` }]}
              >
                <Text style={[styles.actionText, { color: colors.danger }]}>{t('action_block_listing')}</Text>
              </Pressable>
              <Pressable
                disabled={isBusy || l.status === 'deleted'}
                onPress={() => runAction(`listing:${l.id}`, () => store.adminSetListingStatus(l.id, 'deleted', 'Deleted by admin'))}
                style={[styles.actionBtn, { backgroundColor: `${colors.textSecondary}22` }]}
              >
                <Text style={[styles.actionText, { color: colors.textSecondary }]}>{t('action_delete_listing')}</Text>
              </Pressable>
            </ScrollView>
            {isBusy && <ActivityIndicator size="small" color={colors.tint} />}
          </View>
        );
      }}
    />
  );

  const renderComplaints = () => (
    <FlatList
      data={complaints}
      keyExtractor={(item) => item.complaint.id}
      contentContainerStyle={styles.list}
      renderItem={({ item }) => {
        const c = item.complaint;
        const isBusy = busyId === `complaint:${c.id}`;
        return (
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.rowBetween}>
              <View style={[styles.badge, { backgroundColor: `${statusColor[c.status]}22` }]}>
                <Text style={[styles.badgeText, { color: statusColor[c.status] }]}>{t(`status_${c.status}`)}</Text>
              </View>
              <Text style={[styles.meta, { color: colors.textSecondary }]}>{new Date(c.createdAt).toLocaleString()}</Text>
            </View>
            <Text style={[styles.title, { color: colors.text }]}>{getComplaintReasonLabel(c.reason)}</Text>
            <Text style={[styles.meta, { color: colors.textSecondary }]}>{c.description}</Text>
            <Text style={[styles.meta, { color: colors.textSecondary }]}>
              {t('type')}: {getTargetTypeLabel(c.targetType)} | {t('target_complaints_label')}: {item.targetComplaintsCount}
            </Text>
            <Text style={[styles.meta, { color: colors.textSecondary }]}>
              {t('reporter_label')}: {item.reporter?.displayName || c.fromUserId}
            </Text>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.actionsRow}>
              <Pressable
                disabled={isBusy}
                onPress={() => runAction(`complaint:${c.id}`, () => store.setComplaintStatus(c.id, 'in_review', 'In review'))}
                style={[styles.actionBtn, { backgroundColor: `${colors.accent}22` }]}
              >
                <Text style={[styles.actionText, { color: colors.accent }]}>{t('action_in_review')}</Text>
              </Pressable>

              {c.targetType === 'listing' && (
                <>
                  <Pressable
                    disabled={isBusy}
                    onPress={() => runAction(`complaint:${c.id}`, () => store.adminResolveComplaint(c.id, 'block_listing', 'Complaint accepted'))}
                    style={[styles.actionBtn, { backgroundColor: `${colors.danger}22` }]}
                  >
                    <Text style={[styles.actionText, { color: colors.danger }]}>{t('action_block_listing')}</Text>
                  </Pressable>
                  <Pressable
                    disabled={isBusy}
                    onPress={() => runAction(`complaint:${c.id}`, () => store.adminResolveComplaint(c.id, 'delete_listing', 'Complaint accepted'))}
                    style={[styles.actionBtn, { backgroundColor: `${colors.textSecondary}22` }]}
                  >
                    <Text style={[styles.actionText, { color: colors.textSecondary }]}>{t('action_delete_listing')}</Text>
                  </Pressable>
                </>
              )}

              {c.targetType === 'user' && (
                <>
                  <Pressable
                    disabled={isBusy}
                    onPress={() => runAction(`complaint:${c.id}`, () => store.adminResolveComplaint(c.id, 'ban_user', 'Complaint accepted'))}
                    style={[styles.actionBtn, { backgroundColor: `${colors.danger}22` }]}
                  >
                    <Text style={[styles.actionText, { color: colors.danger }]}>{t('action_ban_user')}</Text>
                  </Pressable>
                </>
              )}

              <Pressable
                disabled={isBusy}
                onPress={() => runAction(`complaint:${c.id}`, () => store.adminResolveComplaint(c.id, 'reject', 'Rejected'))}
                style={[styles.actionBtn, { backgroundColor: `${colors.textSecondary}22` }]}
              >
                <Text style={[styles.actionText, { color: colors.textSecondary }]}>{t('action_reject')}</Text>
              </Pressable>
            </ScrollView>
            {isBusy && <ActivityIndicator size="small" color={colors.tint} />}
          </View>
        );
      }}
    />
  );

  const renderFilters = () => {
    const renderChip = (value: string, active: boolean, onPress: () => void) => {
      const chipColor = statusColor[value as keyof typeof statusColor] || colors.tint;
      return (
        <Pressable
          key={value}
          onPress={onPress}
          style={[styles.filterChip, {
            borderColor: active ? chipColor : colors.border,
            backgroundColor: active ? `${chipColor}2A` : colors.surfaceSecondary,
            height: chipHeight,
          }]}
        >
          <Text style={[styles.filterText, {
            color: active ? chipColor : colors.text,
            fontFamily: active ? 'Inter_700Bold' : 'Inter_500Medium',
            fontSize: isSmallScreen ? 12 : 13,
          }]}
            numberOfLines={1}
            ellipsizeMode="tail"
          >
            {t(`status_${value}`)}
          </Text>
        </Pressable>
      );
    };

    if (tab === 'users') {
      return (
        <View style={styles.filtersRow}>
          {USER_STATUS_FILTERS.map((f) => renderChip(f, userStatusFilter === f, () => { setUserStatusFilter(f); }))}
        </View>
      );
    }
    if (tab === 'listings') {
      return (
        <View style={styles.filtersRow}>
          {LISTING_STATUS_FILTERS.map((f) => renderChip(f, listingStatusFilter === f, () => { setListingStatusFilter(f); }))}
        </View>
      );
    }
    return (
      <View style={styles.filtersRow}>
        {COMPLAINT_STATUS_FILTERS.map((f) => renderChip(f, complaintStatusFilter === f, () => { setComplaintStatusFilter(f); }))}
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 8 }]}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t('admin_title')}</Text>
        <Pressable onPress={() => { void loadData(); }}>
          <Ionicons name="refresh" size={22} color={colors.text} />
        </Pressable>
      </View>

      <View style={styles.tabsRow}>
        {(['users', 'listings', 'complaints'] as const).map((name) => (
          <Pressable
            key={name}
            onPress={() => setTab(name)}
            style={[styles.tabBtn, { borderBottomColor: tab === name ? colors.tint : 'transparent' }]}
          >
            <Text style={[styles.tabText, { color: tab === name ? colors.tint : colors.textSecondary }]}>{t(`admin_${name}`)}</Text>
          </Pressable>
        ))}
      </View>

      <View style={styles.searchWrap}>
        <View style={[styles.searchRow, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
          <Ionicons name="search-outline" size={16} color={colors.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: colors.text }]}
            value={search}
            onChangeText={setSearch}
            placeholder={t('admin_search_placeholder')}
            placeholderTextColor={colors.textSecondary}
          />
          <Pressable onPress={() => { void loadData(); }}>
            <Ionicons name="arrow-forward-circle-outline" size={20} color={colors.tint} />
          </Pressable>
        </View>
      </View>

      {renderFilters()}

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.tint} />
        </View>
      ) : (
        <>
          {tab === 'users' && renderUsers()}
          {tab === 'listings' && renderListings()}
          {tab === 'complaints' && renderComplaints()}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerTitle: { fontSize: 28, fontFamily: 'Inter_700Bold' },
  tabsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 14,
    marginBottom: 8,
  },
  tabBtn: {
    borderBottomWidth: 2,
    paddingBottom: 6,
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
  searchWrap: { paddingHorizontal: 16, paddingBottom: 8 },
  searchRow: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    padding: 0,
  },
  filtersRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    paddingBottom: 10,
    gap: 8,
  },
  filterChip: {
    borderWidth: 1.5,
    borderRadius: 999,
    maxWidth: '48%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  filterText: {
    textAlign: 'center',
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 40,
  },
  card: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    gap: 6,
  },
  rowBetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  title: {
    flex: 1,
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
  meta: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
  },
  badge: {
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  badgeText: {
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 8,
    paddingTop: 4,
  },
  actionBtn: {
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  actionText: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  deniedText: {
    marginTop: 8,
    fontSize: 15,
    fontFamily: 'Inter_500Medium',
  },
});
