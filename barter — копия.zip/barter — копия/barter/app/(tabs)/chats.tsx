import React, { useState, useCallback, useEffect } from 'react';
import {
  View, Text, FlatList, Pressable, StyleSheet, Platform, ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useFocusEffect } from 'expo-router';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import { useLanguage } from '@/context/LanguageContext';
import UserAvatar from '@/components/UserAvatar';
import type { ChatRoom, User, Listing, Message } from '@/lib/types';
import * as store from '@/lib/storage';

interface ChatItem {
  room: ChatRoom;
  otherUser: User | null;
  listing: Listing | null;
  lastMessage: Message | null;
}

export default function ChatsScreen() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t } = useLanguage();
  const { currentUser } = useData();
  const [chatItems, setChatItems] = useState<ChatItem[]>([]);
  const [loading, setLoading] = useState(true);

  const loadChats = useCallback(async () => {
    if (!currentUser) return;
    try {
      const rooms = await store.getUserChatRooms(currentUser.id);
      const items = await Promise.all(rooms.map(async (room): Promise<ChatItem> => {
        const otherUserId = room.userAId === currentUser.id ? room.userBId : room.userAId;
        const [otherUser, listing, lastMessage] = await Promise.all([
          store.getUser(otherUserId),
          store.getListing(room.listingId),
          store.getLastMessage(room.id),
        ]);
        return { room, otherUser, listing, lastMessage };
      }));
      setChatItems(items);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  useFocusEffect(useCallback(() => {
    loadChats();
  }, [loadChats]));

  useEffect(() => {
    if (!currentUser) return;
    const unsubscribe = store.subscribeToUserChats(currentUser.id, () => {
      loadChats();
    });
    return unsubscribe;
  }, [currentUser, loadChats]);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const renderItem = ({ item }: { item: ChatItem }) => {
    const timeAgo = getTimeAgo(item.room.lastMessageAt);
    return (
      <Pressable
        onPress={() => router.push({ pathname: '/chat/[id]', params: { id: item.room.id } })}
        style={({ pressed }) => [
          styles.chatRow,
          { backgroundColor: pressed ? colors.surfaceSecondary : 'transparent' },
        ]}
      >
        <UserAvatar
          name={item.otherUser?.displayName || '?'}
          avatar={item.otherUser?.avatar}
          size={50}
        />
        <View style={styles.chatInfo}>
          <View style={styles.chatTop}>
            <Text style={[styles.chatName, { color: colors.text }]} numberOfLines={1}>
              {item.otherUser?.displayName || t('user')}
            </Text>
            <Text style={[styles.chatTime, { color: colors.textSecondary }]}>{timeAgo}</Text>
          </View>
          {item.listing && (
            <Text style={[styles.chatListing, { color: colors.tint }]} numberOfLines={1}>
              {item.listing.title}
            </Text>
          )}
          <Text style={[styles.chatPreview, { color: colors.textSecondary }]} numberOfLines={1}>
            {item.lastMessage?.text || (item.lastMessage?.imageUrl ? t('photo') : t('no_messages_yet'))}
          </Text>
        </View>
      </Pressable>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 8 }]}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t('tab_chats')}</Text>
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.tint} />
        </View>
      ) : (
        <FlatList
          data={chatItems}
          keyExtractor={item => item.room.id}
          renderItem={renderItem}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: Platform.OS === 'web' ? 34 : 100 },
          ]}
          contentInsetAdjustmentBehavior="automatic"
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="chatbubbles-outline" size={48} color={colors.textSecondary} />
              <Text style={[styles.emptyTitle, { color: colors.text }]}>{t('no_chats_yet')}</Text>
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                {t('start_chat_from_listing')}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

function getTimeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'now';
  if (mins < 60) return `${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  return `${days}d`;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12 },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter_700Bold',
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  listContent: { paddingHorizontal: 16 },
  chatRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 4,
    gap: 12,
    borderRadius: 12,
  },
  chatInfo: { flex: 1 },
  chatTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 2,
  },
  chatName: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    flex: 1,
  },
  chatTime: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    marginLeft: 8,
  },
  chatListing: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    marginBottom: 2,
  },
  chatPreview: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
  },
  empty: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100,
    gap: 8,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Inter_600SemiBold',
    marginTop: 8,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
  },
});
