import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, Pressable, TextInput, StyleSheet, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import { router, useFocusEffect } from 'expo-router';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import { useLanguage } from '@/context/LanguageContext';
import UserAvatar from '@/components/UserAvatar';
import ListingCard from '@/components/ListingCard';
import ReviewCard from '@/components/ReviewCard';
import type { Listing, Review, Deal } from '@/lib/types';
import * as store from '@/lib/storage';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark, toggleTheme } = useTheme();
  const { currentUser, updateProfile, logout } = useData();
  const { language, setLanguage, t } = useLanguage();
  const [listings, setListings] = useState<Listing[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [rating, setRating] = useState({ average: 0, count: 0 });
  const [deals, setDeals] = useState<Deal[]>([]);
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [editingBio, setEditingBio] = useState(false);
  const [bioInput, setBioInput] = useState('');
  const [editingPhone, setEditingPhone] = useState(false);
  const [phoneInput, setPhoneInput] = useState('');
  const [tab, setTab] = useState<'listings' | 'reviews' | 'deals'>('listings');

  const loadData = useCallback(async () => {
    if (!currentUser) return;
    const [l, r, rt, d] = await Promise.all([
      store.getUserListings(currentUser.id),
      store.getUserReviews(currentUser.id),
      store.getUserRating(currentUser.id),
      store.getUserDeals(currentUser.id),
    ]);
    setListings(l);
    setReviews(r);
    setRating(rt);
    setDeals(d);
  }, [currentUser]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const pickAvatar = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.5,
    });
    if (!result.canceled && result.assets[0] && currentUser) {
      try {
        const avatarUrl = await store.uploadProfileAvatar(
          result.assets[0].uri,
          currentUser.id,
          result.assets[0].mimeType,
        );
        await updateProfile({ avatar: avatarUrl });
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (e) {
        const message = e instanceof Error ? e.message : 'Failed to upload avatar';
        Alert.alert('Avatar upload failed', message);
      }
    }
  };

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  if (!currentUser) return null;

  const confirmedDeals = deals.filter(d => d.status === 'confirmed');

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: Platform.OS === 'web' ? 34 : 100 }}
      contentInsetAdjustmentBehavior="automatic"
    >
      <View style={{ paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 8 }}>
        <View style={styles.headerRow}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>{t('profile_title')}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            <Pressable onPress={() => { Haptics.selectionAsync(); toggleTheme(); }}>
              <Ionicons
                name={isDark ? 'sunny-outline' : 'moon-outline'}
                size={24}
                color={colors.text}
              />
            </Pressable>
            <Pressable onPress={() => {
              Alert.alert(t('sign_out_title'), t('sign_out_confirm'), [
                { text: t('cancel'), style: 'cancel' },
                {
                  text: t('sign_out'),
                  style: 'destructive',
                  onPress: async () => {
                    await logout();
                    router.replace('/(auth)/login');
                  },
                },
              ]);
            }}>
              <Ionicons name="log-out-outline" size={24} color={colors.danger} />
            </Pressable>
          </View>
        </View>

        <View style={styles.profileSection}>
          <Pressable onPress={pickAvatar} style={styles.avatarWrap}>
            <UserAvatar name={currentUser.displayName} avatar={currentUser.avatar} size={80} />
            <View style={[styles.editBadge, { backgroundColor: colors.tint }]}>
              <Feather name="camera" size={15} color="#fff" />
            </View>
          </Pressable>

          <View style={styles.profileInfo}>
            {editingName ? (
              <View style={styles.editRow}>
                <TextInput
                  style={[styles.nameInput, { color: colors.text, borderColor: colors.border }]}
                  value={nameInput}
                  onChangeText={setNameInput}
                  autoFocus
                  onBlur={() => {
                    if (nameInput.trim()) updateProfile({ displayName: nameInput.trim() });
                    setEditingName(false);
                  }}
                  onSubmitEditing={() => {
                    if (nameInput.trim()) updateProfile({ displayName: nameInput.trim() });
                    setEditingName(false);
                  }}
                />
              </View>
            ) : (
              <Pressable
                onPress={() => { setNameInput(currentUser.displayName); setEditingName(true); }}
                style={styles.editRow}
              >
                <Text style={[styles.profileName, { color: colors.text }]}>
                  {currentUser.displayName}
                </Text>
                <Feather name="edit-2" size={14} color={colors.textSecondary} />
              </Pressable>
            )}

            <Text style={[styles.username, { color: colors.textSecondary }]}>
              @{currentUser.username}
            </Text>

            <View style={styles.statsRow}>
              <View style={styles.statItem}>
                <Text style={[styles.statValue, { color: colors.text }]}>{listings.length}</Text>
                <Text style={[styles.statLabel, { color: colors.textSecondary }]}>{t('listings')}</Text>
              </View>
              <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
              <View style={styles.statItem}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
                  <Ionicons name="star" size={14} color="#EAB308" />
                  <Text style={[styles.statValue, { color: colors.text }]}>
                    {rating.average > 0 ? rating.average.toFixed(1) : '-'}
                  </Text>
                </View>
                <Text style={[styles.statLabel, { color: colors.textSecondary }]}>
                  {rating.count} {t('reviews').toLowerCase()}
                </Text>
              </View>
              <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
              <View style={styles.statItem}>
                <Text style={[styles.statValue, { color: colors.text }]}>{confirmedDeals.length}</Text>
                <Text style={[styles.statLabel, { color: colors.textSecondary }]}>{t('deals')}</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.languageSection}>
          <Text style={[styles.languageTitle, { color: colors.text }]}>{t('language_title')}</Text>
          <View style={styles.languageRow}>
            {([
              { key: 'en', label: t('language_en') },
              { key: 'ru', label: t('language_ru') },
              { key: 'kg', label: t('language_kg') },
            ] as const).map((item) => (
              <Pressable
                key={item.key}
                onPress={() => { void setLanguage(item.key); }}
                style={[styles.languageChip, {
                  borderColor: language === item.key ? colors.tint : colors.border,
                  backgroundColor: language === item.key ? `${colors.tint}22` : colors.surfaceSecondary,
                }]}
              >
                <Text style={[styles.languageChipText, {
                  color: language === item.key ? colors.tint : colors.textSecondary,
                }]}
                >
                  {item.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <Ionicons name="call-outline" size={18} color={colors.textSecondary} />
            {editingPhone ? (
              <TextInput
                style={[styles.infoInput, { color: colors.text, borderColor: colors.border }]}
                value={phoneInput}
                onChangeText={setPhoneInput}
                placeholder="+1-555-0000"
                placeholderTextColor={colors.textSecondary}
                keyboardType="phone-pad"
                autoFocus
                onBlur={() => {
                  updateProfile({ phone: phoneInput.trim() || null });
                  setEditingPhone(false);
                }}
                onSubmitEditing={() => {
                  updateProfile({ phone: phoneInput.trim() || null });
                  setEditingPhone(false);
                }}
              />
            ) : (
              <Pressable
                onPress={() => { setPhoneInput(currentUser.phone || ''); setEditingPhone(true); }}
                style={styles.infoTextRow}
              >
                <Text style={[styles.infoText, { color: currentUser.phone ? colors.text : colors.textSecondary }]}>
                  {currentUser.phone || t('add_phone')}
                </Text>
                <Feather name="edit-2" size={12} color={colors.textSecondary} />
              </Pressable>
            )}
          </View>

          <View style={styles.infoRow}>
            <Ionicons name="document-text-outline" size={18} color={colors.textSecondary} />
            {editingBio ? (
              <TextInput
                style={[styles.infoInput, { color: colors.text, borderColor: colors.border }]}
                value={bioInput}
                onChangeText={setBioInput}
                placeholder="Tell others about yourself..."
                placeholderTextColor={colors.textSecondary}
                multiline
                autoFocus
                onBlur={() => {
                  updateProfile({ bio: bioInput.trim() });
                  setEditingBio(false);
                }}
              />
            ) : (
              <Pressable
                onPress={() => { setBioInput(currentUser.bio || ''); setEditingBio(true); }}
                style={styles.infoTextRow}
              >
                <Text style={[styles.infoText, {
                  color: currentUser.bio ? colors.text : colors.textSecondary,
                  flex: 1,
                }]} numberOfLines={2}>
                  {currentUser.bio || t('add_bio')}
                </Text>
                <Feather name="edit-2" size={12} color={colors.textSecondary} />
              </Pressable>
            )}
          </View>
        </View>

        <View style={styles.tabRow}>
          {(['listings', 'reviews', 'deals'] as const).map(tabName => (
            <Pressable
              key={tabName}
              onPress={() => { Haptics.selectionAsync(); setTab(tabName); }}
              style={[
                styles.tabBtn,
                { borderBottomColor: tab === tabName ? colors.tint : 'transparent' },
              ]}
            >
              <Text style={[
                styles.tabText,
                { color: tab === tabName ? colors.tint : colors.textSecondary },
              ]}>
                {t(tabName)}
              </Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.tabContent}>
          {tab === 'listings' && (
            listings.length === 0 ? (
              <View style={styles.emptySection}>
                <Ionicons name="pricetag-outline" size={32} color={colors.textSecondary} />
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t('no_listings_yet')}</Text>
              </View>
            ) : (
              listings.map(l => (
                <ListingCard
                  key={l.id}
                  listing={l}
                  compact
                  onPress={() => router.push({ pathname: '/listing/[id]', params: { id: l.id } })}
                />
              ))
            )
          )}
          {tab === 'reviews' && (
            reviews.length === 0 ? (
              <View style={styles.emptySection}>
                <Ionicons name="star-outline" size={32} color={colors.textSecondary} />
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t('no_reviews_yet')}</Text>
              </View>
            ) : (
              reviews.map(r => <ReviewCard key={r.id} review={r} />)
            )
          )}
          {tab === 'deals' && (
            confirmedDeals.length === 0 ? (
              <View style={styles.emptySection}>
                <Ionicons name="people-outline" size={32} color={colors.textSecondary} />
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t('no_completed_deals')}</Text>
              </View>
            ) : (
              confirmedDeals.map(d => (
                <DealRow key={d.id} deal={d} currentUserId={currentUser.id} colors={colors} />
              ))
            )
          )}
        </View>
      </View>
    </ScrollView>
  );
}

function DealRow({ deal, currentUserId, colors }: { deal: Deal; currentUserId: string; colors: any }) {
  const [listing, setListing] = useState<any>(null);
  const [reviewed, setReviewed] = useState(false);

  React.useEffect(() => {
    store.getListing(deal.listingId).then(setListing);
    store.getReviewForDeal(deal.id, currentUserId).then(r => setReviewed(!!r));
  }, [deal]);

  return (
    <Pressable
      onPress={() => {
        if (!reviewed) {
          router.push({ pathname: '/review/[dealId]', params: { dealId: deal.id } });
        }
      }}
      style={[styles.dealRow, { backgroundColor: colors.surface, borderColor: colors.border }]}
    >
      <View style={styles.dealInfo}>
        <Text style={[styles.dealTitle, { color: colors.text }]} numberOfLines={1}>
          {listing?.title || 'Loading...'}
        </Text>
        <View style={[styles.dealStatus, { backgroundColor: colors.success + '20' }]}>
          <Ionicons name="checkmark-circle" size={14} color={colors.success} />
          <Text style={[styles.dealStatusText, { color: colors.success }]}>Confirmed</Text>
        </View>
      </View>
      {reviewed ? (
        <View style={styles.reviewedBadge}>
          <Ionicons name="star" size={14} color="#EAB308" />
          <Text style={[styles.reviewedText, { color: colors.textSecondary }]}>Reviewed</Text>
        </View>
      ) : (
        <View style={styles.reviewedBadge}>
          <Ionicons name="create-outline" size={14} color={colors.tint} />
          <Text style={[styles.reviewedText, { color: colors.tint }]}>Leave review</Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter_700Bold',
  },
  profileSection: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 16,
    marginBottom: 20,
  },
  avatarWrap: {
    position: 'relative',
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  editBadge: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 30,
    height: 30,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: '#111',
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  editRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  profileName: {
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
  },
  nameInput: {
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
    borderBottomWidth: 1,
    paddingBottom: 2,
    flex: 1,
  },
  username: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    marginTop: 2,
    marginBottom: 12,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  statItem: { alignItems: 'center' },
  statValue: {
    fontSize: 16,
    fontFamily: 'Inter_700Bold',
  },
  statLabel: {
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    marginTop: 1,
  },
  statDivider: {
    width: 1,
    height: 28,
  },
  languageSection: {
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  languageTitle: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
    marginBottom: 8,
  },
  languageRow: {
    flexDirection: 'row',
    gap: 8,
  },
  languageChip: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  languageChipText: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
  },
  infoSection: {
    paddingHorizontal: 20,
    gap: 12,
    marginBottom: 20,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoTextRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
  },
  infoInput: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    borderBottomWidth: 1,
    paddingBottom: 2,
    flex: 1,
  },
  tabRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 20,
    marginBottom: 16,
  },
  tabBtn: {
    paddingBottom: 8,
    borderBottomWidth: 2,
  },
  tabText: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
  tabContent: {
    paddingHorizontal: 20,
  },
  emptySection: {
    alignItems: 'center',
    paddingVertical: 40,
    gap: 8,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
  },
  dealRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 8,
    justifyContent: 'space-between',
  },
  dealInfo: {
    flex: 1,
    gap: 4,
  },
  dealTitle: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
  dealStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  dealStatusText: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
  reviewedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginLeft: 8,
  },
  reviewedText: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
});
