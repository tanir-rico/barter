import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, FlatList, TextInput, Pressable, StyleSheet, Platform, Alert, ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { Image } from 'expo-image';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import { useLanguage } from '@/context/LanguageContext';
import UserAvatar from '@/components/UserAvatar';
import type { ChatRoom, Message, User, Listing, Deal } from '@/lib/types';
import * as store from '@/lib/storage';

export default function ChatDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t } = useLanguage();
  const { currentUser } = useData();
  const [room, setRoom] = useState<ChatRoom | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [otherUser, setOtherUser] = useState<User | null>(null);
  const [listing, setListing] = useState<Listing | null>(null);
  const [deal, setDeal] = useState<Deal | null>(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [sendingImage, setSendingImage] = useState(false);
  const inputRef = useRef<TextInput>(null);

  const runWithConfirm = useCallback(
    async (title: string, message: string, action: () => Promise<void>) => {
      if (Platform.OS === 'web') {
        const ok = globalThis.confirm?.(`${title}\n\n${message}`) ?? true;
        if (!ok) return;
        await action();
        return;
      }

      Alert.alert(title, message, [
        { text: t('cancel'), style: 'cancel' },
        {
          text: t('confirm'),
          onPress: () => {
            void action();
          },
        },
      ]);
    },
    [t],
  );

  const loadHeaderData = useCallback(async () => {
    if (!id || !currentUser) return;
    try {
      const r = await store.getChatRoom(id);
      setRoom(r);
      if (r) {
        const otherId = r.userAId === currentUser.id ? r.userBId : r.userAId;
        const [u, l] = await Promise.all([
          store.getUser(otherId),
          store.getListing(r.listingId),
        ]);
        setOtherUser(u);
        setListing(l);
      }
    } catch (e) {
      console.error(e);
    }
  }, [id, currentUser]);

  const loadConversationData = useCallback(async () => {
    if (!id) return;
    try {
      const [msgs, d] = await Promise.all([
        store.getChatMessages(id),
        store.getDealForChat(id),
      ]);
      setMessages(msgs);
      setDeal(d);
    } catch (e) {
      console.error(e);
    }
  }, [id]);

  const loadData = useCallback(async () => {
    setLoading(true);
    await Promise.all([loadHeaderData(), loadConversationData()]);
    setLoading(false);
  }, [loadHeaderData, loadConversationData]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  useEffect(() => {
    if (!id || !currentUser) return;
    const unsubscribe = store.subscribeToChatRoom(id, (payload) => {
      if (payload?.table === 'messages' && payload?.eventType === 'INSERT' && payload?.new) {
        const incoming: Message = {
          id: payload.new.id,
          chatRoomId: payload.new.chat_room_id,
          senderId: payload.new.sender_id,
          text: payload.new.text || '',
          imageUrl: payload.new.image_url,
          createdAt: Date.parse(payload.new.created_at) || Date.now(),
        };
        setMessages((prev) => (prev.some((m) => m.id === incoming.id) ? prev : [...prev, incoming]));
        return;
      }
      loadConversationData();
    });
    return unsubscribe;
  }, [id, currentUser, loadConversationData]);

  const handleSend = async () => {
    if (!input.trim() || !room || !currentUser) return;
    const text = input.trim();
    setInput('');
    await store.sendMessage(room.id, currentUser.id, text);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    inputRef.current?.focus();
  };

  const handleSendImage = async () => {
    if (!room || !currentUser || sendingImage) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.75,
      allowsEditing: false,
      allowsMultipleSelection: false,
    });
    if (result.canceled || !result.assets[0]) return;

    setSendingImage(true);
    try {
      const imageUrl = await store.uploadChatImage(
        result.assets[0].uri,
        currentUser.id,
        result.assets[0].mimeType,
      );
      await store.sendMessage(room.id, currentUser.id, '', imageUrl);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    } catch (e) {
      const message = e instanceof Error ? e.message : t('chat_failed_send_image');
      Alert.alert(t('error'), message);
    } finally {
      setSendingImage(false);
    }
  };

  const handleProposeDeal = async () => {
    if (!room || !currentUser || !listing) return;
    if (deal) {
      Alert.alert(t('chat_deal_exists_title'), t('chat_deal_exists_message'));
      return;
    }
    await runWithConfirm(t('chat_propose_deal_title'), t('chat_propose_deal_message'), async () => {
      const otherId = room.userAId === currentUser.id ? room.userBId : room.userAId;
      const d = await store.proposeDeal(room.id, room.listingId, currentUser.id, currentUser.id, otherId);
      setDeal(d);
      await store.sendMessage(room.id, currentUser.id, `[${t('chat_deal_proposed_waiting')}]`);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    });
  };

  const handleConfirmDeal = async () => {
    if (!deal) return;
    await runWithConfirm(t('chat_confirm_deal_title'), t('chat_confirm_deal_message'), async () => {
      const d = await store.confirmDeal(deal.id);
      if (d) {
        setDeal(d);
        if (room && currentUser) {
          await store.sendMessage(room.id, currentUser.id, `[${t('chat_deal_confirmed_complete')}]`);
        }
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    });
  };

  const handleCancelDeal = async () => {
    if (!deal) return;
    await runWithConfirm(t('chat_cancel_deal_title'), t('chat_cancel_deal_message'), async () => {
      const d = await store.cancelDeal(deal.id);
      if (d) {
        setDeal(null);
        if (room && currentUser) {
          await store.sendMessage(room.id, currentUser.id, `[${t('chat_deal_canceled')}]`);
        }
      }
    });
  };

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const renderMessage = ({ item }: { item: Message }) => {
    const isMe = item.senderId === currentUser?.id;
    const isSystem = item.text.startsWith('[') && item.text.endsWith(']');

    if (isSystem) {
      return (
        <View style={styles.systemMsg}>
          <Text style={[styles.systemText, { color: colors.tint }]}>{item.text.slice(1, -1)}</Text>
        </View>
      );
    }

    return (
      <View style={[styles.msgRow, isMe && styles.msgRowMe]}>
        <View style={[
          styles.bubble,
          isMe
            ? { backgroundColor: colors.tint, borderBottomRightRadius: 4 }
            : { backgroundColor: colors.surfaceSecondary, borderBottomLeftRadius: 4 },
        ]}>
          {item.imageUrl && (
            <Image source={{ uri: item.imageUrl }} style={styles.msgImage} contentFit="cover" />
          )}
          {!!item.text && (
            <Text style={[styles.msgText, { color: isMe ? '#fff' : colors.text }]}>
              {item.text}
            </Text>
          )}
          <Text style={[styles.msgTime, { color: isMe ? 'rgba(255,255,255,0.7)' : colors.textSecondary }]}>
            {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </Text>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.tint} />
      </View>
    );
  }

  const canPropose = deal === null && listing?.status === 'active';
  const canConfirm = deal?.status === 'proposed' && deal.proposedBy !== currentUser?.id;
  const canCancel = deal?.status === 'proposed';
  const canReview = deal?.status === 'confirmed';

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </Pressable>
        <Pressable
          onPress={() => otherUser && router.push({ pathname: '/user/[id]', params: { id: otherUser.id } })}
          style={styles.headerUser}
        >
          <UserAvatar name={otherUser?.displayName || '?'} avatar={otherUser?.avatar} size={36} />
          <View>
            <Text style={[styles.headerName, { color: colors.text }]} numberOfLines={1}>
              {otherUser?.displayName || t('user')}
            </Text>
            {listing && (
              <Text style={[styles.headerListing, { color: colors.tint }]} numberOfLines={1}>
                {listing.title}
              </Text>
            )}
          </View>
        </Pressable>
        <Pressable
          onPress={() => {
            if (otherUser) {
              router.push({
                pathname: '/complaint',
                params: { targetType: 'user', targetId: otherUser.id },
              });
            }
          }}
        >
          <Ionicons name="flag-outline" size={20} color={colors.textSecondary} />
        </Pressable>
      </View>

      {deal && (
        <View style={[styles.dealBanner, {
          backgroundColor: deal.status === 'confirmed' ? colors.success + '15' : colors.accent + '15',
          borderBottomColor: colors.border,
        }]}>
          <Ionicons
            name={deal.status === 'confirmed' ? 'checkmark-circle' : 'time-outline'}
            size={18}
            color={deal.status === 'confirmed' ? colors.success : colors.accent}
          />
          <Text style={[styles.dealBannerText, {
            color: deal.status === 'confirmed' ? colors.success : colors.accent,
          }]}>
            {deal.status === 'confirmed' ? t('chat_deal_completed') : t('chat_deal_proposed_awaiting')}
          </Text>
          {canConfirm && (
            <Pressable
              onPress={handleConfirmDeal}
              style={[styles.dealAction, { backgroundColor: colors.success }]}
            >
              <Ionicons name="checkmark" size={16} color="#fff" />
            </Pressable>
          )}
          {canCancel && (
            <Pressable
              onPress={handleCancelDeal}
              style={[styles.dealAction, { backgroundColor: colors.danger }]}
            >
              <Ionicons name="close" size={16} color="#fff" />
            </Pressable>
          )}
          {canReview && (
            <Pressable
              onPress={() => router.push({ pathname: '/review/[dealId]', params: { dealId: deal.id } })}
              style={[styles.dealAction, { backgroundColor: colors.tint }]}
            >
              <Ionicons name="star-outline" size={16} color="#fff" />
            </Pressable>
          )}
        </View>
      )}

      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" keyboardVerticalOffset={0}>
        <FlatList
          data={messages}
          keyExtractor={item => item.id}
          renderItem={renderMessage}
          contentContainerStyle={[styles.msgList, { paddingBottom: 8, paddingTop: 8 }]}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
          ListEmptyComponent={
            <View style={styles.emptyChat}>
              <Ionicons name="chatbubble-ellipses-outline" size={40} color={colors.textSecondary} />
              <Text style={[styles.emptyChatText, { color: colors.textSecondary }]}>
                {t('chat_empty_start')}
              </Text>
            </View>
          }
        />

        <View style={[styles.inputBar, {
          paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 4,
          backgroundColor: colors.background,
          borderTopColor: colors.border,
        }]}>
          {canPropose && (
            <Pressable onPress={handleProposeDeal} style={[styles.dealBtn, { backgroundColor: colors.accent + '20' }]}>
              <Ionicons name="people-outline" size={20} color={colors.accent} />
            </Pressable>
          )}
          <View style={[styles.inputContainer, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
            <TextInput
              ref={inputRef}
              style={[styles.textInput, { color: colors.text }]}
              value={input}
              onChangeText={setInput}
              placeholder={t('chat_type_message')}
              placeholderTextColor={colors.textSecondary}
              multiline
              maxLength={1000}
            />
          </View>
          <Pressable
            onPress={handleSendImage}
            disabled={sendingImage}
            style={({ pressed }) => [
              styles.sendBtn,
              {
                backgroundColor: colors.surfaceSecondary,
                opacity: pressed || sendingImage ? 0.7 : 1,
              },
            ]}
          >
            {sendingImage ? (
              <ActivityIndicator size="small" color={colors.textSecondary} />
            ) : (
              <Ionicons name="image-outline" size={18} color={colors.textSecondary} />
            )}
          </Pressable>
          <Pressable
            onPress={handleSend}
            disabled={!input.trim()}
            style={({ pressed }) => [
              styles.sendBtn,
              {
                backgroundColor: input.trim() ? colors.tint : colors.surfaceSecondary,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
          >
            <Ionicons name="send" size={18} color={input.trim() ? '#fff' : colors.textSecondary} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 10,
    gap: 12,
    borderBottomWidth: 1,
  },
  headerUser: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  headerName: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
  headerListing: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
  dealBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    gap: 8,
    borderBottomWidth: 1,
  },
  dealBannerText: {
    flex: 1,
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
  dealAction: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  msgList: {
    paddingHorizontal: 16,
  },
  msgRow: {
    marginBottom: 6,
    alignItems: 'flex-start',
  },
  msgRowMe: {
    alignItems: 'flex-end',
  },
  bubble: {
    maxWidth: '80%',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 18,
  },
  msgText: {
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    lineHeight: 20,
  },
  msgImage: {
    width: 220,
    height: 220,
    borderRadius: 12,
    marginBottom: 6,
  },
  msgTime: {
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  systemMsg: {
    alignItems: 'center',
    marginVertical: 10,
  },
  systemText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    fontStyle: 'italic',
  },
  emptyChat: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 60,
    gap: 10,
  },
  emptyChatText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 12,
    paddingTop: 8,
    gap: 8,
    borderTopWidth: 1,
  },
  dealBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
  inputContainer: {
    flex: 1,
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 8,
    minHeight: 40,
    maxHeight: 120,
    justifyContent: 'center',
  },
  textInput: {
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    maxHeight: 100,
    padding: 0,
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
});
