import React, { useState } from 'react';
import {
  View, Text, Pressable, TextInput, StyleSheet, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import { useLanguage } from '@/context/LanguageContext';
import * as store from '@/lib/storage';

export default function ComplaintScreen() {
  const { targetType, targetId } = useLocalSearchParams<{ targetType: string; targetId: string }>();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t } = useLanguage();
  const { currentUser } = useData();
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  const REASONS = [
    t('reason_spam'),
    t('reason_inappropriate'),
    t('reason_harassment'),
    t('reason_misleading'),
    t('reason_stolen'),
    t('reason_other'),
  ];

  const handleSubmit = async () => {
    if (!currentUser || !targetType || !targetId) {
      Alert.alert(t('error'), t('report_missing_target'));
      return;
    }
    if (!reason) {
      Alert.alert(t('report_select_reason'));
      return;
    }
    if (!description.trim()) {
      Alert.alert(t('report_add_description'));
      return;
    }

    setSaving(true);
    try {
      await store.createComplaint({
        fromUserId: currentUser.id,
        targetType: targetType as 'listing' | 'user',
        targetId,
        reason,
        description: description.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert(t('report_submitted_title'), t('report_submitted_message'));
      router.back();
    } catch (e) {
      const message = e instanceof Error ? e.message : t('report_failed');
      Alert.alert(t('error'), message);
    } finally {
      setSaving(false);
    }
  };

  const webTopInset = Platform.OS === 'web' ? 20 : 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4 }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name="close" size={26} color={colors.text} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t('report_title')}</Text>
        <View style={{ width: 26 }} />
      </View>

      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 20 }}
        bottomOffset={20}
      >
        <View style={styles.infoBox}>
          <Ionicons name="shield-outline" size={20} color={colors.tint} />
          <Text style={[styles.infoText, { color: colors.textSecondary }]}>
            {targetType === 'user' ? t('report_info_user') : t('report_info_listing')}
          </Text>
        </View>

        <Text style={[styles.label, { color: colors.text }]}>{t('report_reason')}</Text>
        {REASONS.map(r => (
          <Pressable
            key={r}
            onPress={() => { setReason(r); Haptics.selectionAsync(); }}
            style={[
              styles.reasonBtn,
              {
                backgroundColor: reason === r ? colors.tint + '15' : colors.surfaceSecondary,
                borderColor: reason === r ? colors.tint : colors.border,
              },
            ]}
          >
            <Ionicons
              name={reason === r ? 'radio-button-on' : 'radio-button-off'}
              size={20}
              color={reason === r ? colors.tint : colors.textSecondary}
            />
            <Text style={[styles.reasonText, { color: reason === r ? colors.tint : colors.text }]}>
              {r}
            </Text>
          </Pressable>
        ))}

        <Text style={[styles.label, { color: colors.text, marginTop: 20 }]}>{t('report_description')}</Text>
        <TextInput
          style={[styles.textArea, {
            color: colors.text,
            backgroundColor: colors.surfaceSecondary,
            borderColor: colors.border,
          }]}
          value={description}
          onChangeText={setDescription}
          placeholder={t('report_placeholder')}
          placeholderTextColor={colors.textSecondary}
          multiline
          textAlignVertical="top"
          maxLength={500}
        />

        <Pressable
          onPress={handleSubmit}
          disabled={saving || !reason || !description.trim()}
          style={({ pressed }) => [
            styles.submitBtn,
            {
              backgroundColor: reason && description.trim() ? colors.danger : colors.surfaceSecondary,
              opacity: pressed || saving ? 0.7 : 1,
            },
          ]}
        >
          <Text style={[styles.submitText, {
            color: reason && description.trim() ? '#fff' : colors.textSecondary,
          }]}>
            {saving ? t('report_submitting') : t('report_submit')}
          </Text>
        </Pressable>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  headerTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold' },
  scroll: { flex: 1 },
  infoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 14,
    marginBottom: 10,
  },
  infoText: { flex: 1, fontSize: 14, fontFamily: 'Inter_400Regular', lineHeight: 20 },
  label: { fontSize: 15, fontFamily: 'Inter_600SemiBold', marginBottom: 10 },
  reasonBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 8,
  },
  reasonText: { fontSize: 15, fontFamily: 'Inter_400Regular' },
  textArea: {
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    minHeight: 100,
  },
  submitBtn: {
    marginTop: 24,
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
  },
  submitText: { fontSize: 16, fontFamily: 'Inter_600SemiBold' },
});
