﻿import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, Pressable, StyleSheet, Platform, Alert, Linking,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Image } from 'expo-image';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import { useLanguage } from '@/context/LanguageContext';
import UserAvatar from '@/components/UserAvatar';
import type { Listing, User } from '@/lib/types';
import * as store from '@/lib/storage';

export default function ListingDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { language, t } = useLanguage();
  const { currentUser } = useData();
  const [listing, setListing] = useState<Listing | null>(null);
  const [author, setAuthor] = useState<User | null>(null);
  const [authorRating, setAuthorRating] = useState({ average: 0, count: 0 });

  useFocusEffect(useCallback(() => {
    loadData();
  }, [id]));

  async function loadData() {
    if (!id) return;
    const l = await store.getListing(id);
    setListing(l);
    if (l) {
      const a = await store.getUser(l.authorId);
      setAuthor(a);
      if (a) {
        const r = await store.getUserRating(a.id);
        setAuthorRating(r);
      }
    }
  }

  const isOwner = currentUser?.id === listing?.authorId;

  const handleStartChat = async () => {
    if (!currentUser || !listing || !author) return;
    if (isOwner) return;
    const room = await store.getOrCreateChatRoom(listing.id, currentUser.id, author.id);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({ pathname: '/chat/[id]', params: { id: room.id } });
  };

  const handleDelete = () => {
    Alert.alert(t('action_delete_listing'), t('confirm_delete_listing'), [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('action_delete_listing'), style: 'destructive', onPress: async () => {
          if (listing) {
            await store.deleteListing(listing.id);
            router.back();
          }
        },
      },
    ]);
  };

  const handleCallAuthor = () => {
    if (author?.phone) {
      Linking.openURL(`tel:${author.phone}`);
    }
  };

  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const CATEGORY_TRANSLATIONS: Record<string, { ru: string; kg: string }> = {
    Fiction: { ru: 'Художественная литература', kg: 'Көркөм адабият' },
    'Non-Fiction': { ru: 'Нон-фикшн', kg: 'Нон-фикшн' },
    Science: { ru: 'Наука', kg: 'Илим' },
    Technology: { ru: 'Технологии', kg: 'Технология' },
    Art: { ru: 'Искусство', kg: 'Өнөр' },
    Music: { ru: 'Музыка', kg: 'Музыка' },
    Sports: { ru: 'Спорт', kg: 'Спорт' },
    Clothing: { ru: 'Одежда', kg: 'Кийим' },
    Electronics: { ru: 'Электроника', kg: 'Электроника' },
    Furniture: { ru: 'Мебель', kg: 'Эмерек' },
    'Home & Garden': { ru: 'Дом и сад', kg: 'Үй жана бакча' },
    Auto: { ru: 'Авто', kg: 'Авто' },
    'Games & Toys': { ru: 'Игры и игрушки', kg: 'Оюндар жана оюнчуктар' },
    Pets: { ru: 'Питомцы', kg: 'Үй жаныбарлары' },
    'Baby & Kids': { ru: 'Для детей', kg: 'Балдар үчүн' },
    'Health & Beauty': { ru: 'Здоровье и красота', kg: 'Ден соолук жана сулуулук' },
    Education: { ru: 'Образование', kg: 'Билим берүү' },
    Design: { ru: 'Дизайн', kg: 'Дизайн' },
    Photography: { ru: 'Фотография', kg: 'Сүрөт тартуу' },
    Cooking: { ru: 'Кулинария', kg: 'Ашкана' },
    Languages: { ru: 'Языки', kg: 'Тилдер' },
    Repair: { ru: 'Ремонт', kg: 'Оңдоо' },
    Collectibles: { ru: 'Коллекции', kg: 'Коллекциялар' },
    Business: { ru: 'Бизнес', kg: 'Бизнес' },
    Travel: { ru: 'Путешествия', kg: 'Саякат' },
    Other: { ru: 'Другое', kg: 'Башка' },
  };
  const getCategoryLabel = (value: string) => {
    if (language === 'en') return value;
    const row = CATEGORY_TRANSLATIONS[value];
    if (!row) return value;
    return language === 'ru' ? row.ru : row.kg;
  };
  const typeLabelMap: Record<string, string> = {
    book: t('type_book'),
    item: t('type_item'),
    service: t('type_service'),
  };

  if (!listing) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.topBar, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4 }]}>
          <Pressable onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </Pressable>
        </View>
        <View style={styles.center}>
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t('no_listings_found')}</Text>
        </View>
      </View>
    );
  }

  const typeColor = listing.type === 'book' ? '#3B82F6' : listing.type === 'service' ? colors.tint : colors.accent;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.topBar, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4 }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </Pressable>
        <View style={styles.topActions}>
          <Pressable
            onPress={() => {
              router.push({
                pathname: '/complaint',
                params: { targetType: 'listing', targetId: listing.id },
              });
            }}
          >
            <Ionicons name="flag-outline" size={22} color={colors.textSecondary} />
          </Pressable>
          {isOwner && (
            <>
              <Pressable onPress={() => router.push({ pathname: '/listing/edit/[id]', params: { id: listing.id } })}>
                <Ionicons name="create-outline" size={22} color={colors.text} />
              </Pressable>
              <Pressable onPress={handleDelete}>
                <Ionicons name="trash-outline" size={22} color={colors.danger} />
              </Pressable>
            </>
          )}
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: isOwner ? insets.bottom + 20 : insets.bottom + 80 }}
        contentInsetAdjustmentBehavior="automatic"
      >
        {listing.photos.length > 0 && (
          <ScrollView horizontal pagingEnabled showsHorizontalScrollIndicator={false} style={styles.photoScroll}>
            {listing.photos.map((uri, i) => (
              <Image key={i} source={{ uri }} style={styles.photoImage} contentFit="cover" />
            ))}
          </ScrollView>
        )}

        <View style={styles.content}>
          <View style={[styles.typeTag, { backgroundColor: typeColor + '18' }]}>
            <Text style={[styles.typeText, { color: typeColor }]}>
              {typeLabelMap[listing.type] || listing.type}
            </Text>
          </View>

          <Text style={[styles.title, { color: colors.text }]}>{listing.title}</Text>

          {listing.status === 'closed' && (
            <View style={[styles.closedBadge, { backgroundColor: colors.success + '20' }]}>
              <Ionicons name="checkmark-circle" size={16} color={colors.success} />
              <Text style={[styles.closedText, { color: colors.success }]}>{t('deal_completed')}</Text>
            </View>
          )}

          <Text style={[styles.description, { color: colors.text }]}>{listing.description}</Text>

          <View style={[styles.exchangeCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.exchangeItem}>
              <Ionicons name="arrow-up-circle" size={20} color={colors.tint} />
              <View style={styles.exchangeInfo}>
                <Text style={[styles.exchangeLabel, { color: colors.textSecondary }]}>{t('what_i_offer')}</Text>
                <Text style={[styles.exchangeValue, { color: colors.text }]}>{listing.offering}</Text>
              </View>
            </View>
            <View style={[styles.exchangeDivider, { backgroundColor: colors.border }]} />
            <View style={styles.exchangeItem}>
              <Ionicons name="arrow-down-circle" size={20} color={colors.accent} />
              <View style={styles.exchangeInfo}>
                <Text style={[styles.exchangeLabel, { color: colors.textSecondary }]}>{t('what_i_want')}</Text>
                <Text style={[styles.exchangeValue, { color: colors.text }]}>{listing.wantInReturn}</Text>
              </View>
            </View>
          </View>

          <View style={[styles.categoryRow, { backgroundColor: colors.surfaceSecondary }]}>
            <Ionicons name="pricetag-outline" size={16} color={colors.textSecondary} />
            <Text style={[styles.categoryText, { color: colors.textSecondary }]}>{getCategoryLabel(listing.category)}</Text>
          </View>

          {author && (
            <Pressable
              onPress={() => {
                if (!isOwner) router.push({ pathname: '/user/[id]', params: { id: author.id } });
              }}
              style={[styles.authorCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
            >
              <UserAvatar name={author.displayName} avatar={author.avatar} size={44} />
              <View style={styles.authorInfo}>
                <Text style={[styles.authorName, { color: colors.text }]}>{author.displayName}</Text>
                <View style={styles.authorRating}>
                  <Ionicons name="star" size={14} color="#EAB308" />
                  <Text style={[styles.authorRatingText, { color: colors.textSecondary }]}>
                    {authorRating.average > 0 ? `${authorRating.average.toFixed(1)} (${authorRating.count})` : t('no_reviews_yet')}
                  </Text>
                </View>
              </View>
              {author.phone && (
                <Pressable
                  onPress={(e) => { e.stopPropagation(); handleCallAuthor(); }}
                  style={[styles.callBtn, { backgroundColor: colors.success + '15' }]}
                >
                  <Ionicons name="call" size={18} color={colors.success} />
                </Pressable>
              )}
              {!isOwner && <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />}
            </Pressable>
          )}
        </View>
      </ScrollView>

      {!isOwner && listing.status === 'active' && (
        <View style={[styles.bottomBar, {
          paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 8,
          backgroundColor: colors.background,
          borderTopColor: colors.border,
        }]}>
          <Pressable
            onPress={handleStartChat}
            style={({ pressed }) => [
              styles.chatBtn,
              { backgroundColor: colors.tint, opacity: pressed ? 0.8 : 1 },
            ]}
          >
            <Ionicons name="chatbubble-outline" size={20} color="#fff" />
            <Text style={styles.chatBtnText}>{t('start_chat')}</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  topActions: {
    flexDirection: 'row',
    gap: 16,
    alignItems: 'center',
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: { fontSize: 16, fontFamily: 'Inter_400Regular' },
  photoScroll: { height: 260 },
  photoImage: { width: 380, height: 260 },
  content: { paddingHorizontal: 20, paddingTop: 16 },
  typeTag: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
    marginBottom: 10,
  },
  typeText: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    lineHeight: 30,
    marginBottom: 8,
  },
  closedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    marginBottom: 12,
  },
  closedText: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
  },
  description: {
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    lineHeight: 22,
    marginBottom: 16,
  },
  exchangeCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 12,
  },
  exchangeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  exchangeInfo: { flex: 1 },
  exchangeLabel: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
  exchangeValue: {
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    marginTop: 2,
  },
  exchangeDivider: {
    height: 1,
    marginVertical: 10,
  },
  categoryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    marginBottom: 16,
  },
  categoryText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
  authorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    marginBottom: 16,
  },
  authorInfo: { flex: 1 },
  authorName: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
  authorRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  authorRatingText: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
  },
  callBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingTop: 12,
    borderTopWidth: 1,
  },
  chatBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
  },
  chatBtnText: {
    color: '#fff',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
});

