﻿import React, { useState } from 'react';
import {
  View, Text, Pressable, TextInput, StyleSheet, Platform, Alert, ScrollView,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { Image } from 'expo-image';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import { useLanguage } from '@/context/LanguageContext';
import * as store from '@/lib/storage';
import { CATEGORIES, ListingType } from '@/lib/types';

export default function CreateListingScreen() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t, language } = useLanguage();
  const { currentUser } = useData();
  const [type, setType] = useState<ListingType>('item');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState<{ uri: string; mimeType?: string | null }[]>([]);
  const [category, setCategory] = useState('');
  const [offering, setOffering] = useState('');
  const [wantInReturn, setWantInReturn] = useState('');
  const [showCategories, setShowCategories] = useState(false);
  const [saving, setSaving] = useState(false);

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      quality: 0.7,
      selectionLimit: 5 - photos.length,
    });
    if (!result.canceled) {
      setPhotos(prev => [
        ...prev,
        ...result.assets.map(a => ({ uri: a.uri, mimeType: a.mimeType })),
      ].slice(0, 5));
    }
  };

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!currentUser) return;
    if (!title.trim()) {
      Alert.alert(t('title_required'));
      return;
    }
    if (!offering.trim()) {
      Alert.alert(t('describe_offer_required'));
      return;
    }
    if (!wantInReturn.trim()) {
      Alert.alert(t('describe_want_required'));
      return;
    }

    setSaving(true);
    try {
      const uploadedPhotos = await Promise.all(
        photos.map((p) => store.uploadListingImage(p.uri, currentUser.id, p.mimeType)),
      );
      await store.createListing({
        authorId: currentUser.id,
        type,
        title: title.trim(),
        description: description.trim(),
        photos: uploadedPhotos,
        category: category || 'Other',
        offering: offering.trim(),
        wantInReturn: wantInReturn.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (e) {
      const message = e instanceof Error ? e.message : t('create_listing_failed');
      Alert.alert(t('error'), message);
    } finally {
      setSaving(false);
    }
  };

  const webTopInset = Platform.OS === 'web' ? 20 : 0;
  const CATEGORY_TRANSLATIONS: Record<string, { ru: string; kg: string }> = {
    Fiction: { ru: 'Художественная литература', kg: 'Көркөм адабият' },
    'Non-Fiction': { ru: 'Нон-фикшн', kg: 'Нон-фикшн' },
    Science: { ru: 'Наука', kg: 'Илим' },
    Technology: { ru: 'Технологии', kg: 'Технология' },
    Art: { ru: 'Искусство', kg: 'Өнөр' },
    Music: { ru: 'Музыка', kg: 'Музыка' },
    Sports: { ru: 'Спорт', kg: 'Спорт' },
    Clothing: { ru: 'Одежда', kg: 'Кийим' },
    Electronics: { ru: 'Электроника', kg: 'Электроника' },
    Furniture: { ru: 'Мебель', kg: 'Эмерек' },
    'Home & Garden': { ru: 'Дом и сад', kg: 'Үй жана бакча' },
    Auto: { ru: 'Авто', kg: 'Авто' },
    'Games & Toys': { ru: 'Игры и игрушки', kg: 'Оюндар жана оюнчуктар' },
    Pets: { ru: 'Питомцы', kg: 'Үй жаныбарлары' },
    'Baby & Kids': { ru: 'Для детей', kg: 'Балдар үчүн' },
    'Health & Beauty': { ru: 'Здоровье и красота', kg: 'Ден соолук жана сулуулук' },
    Education: { ru: 'Образование', kg: 'Билим берүү' },
    Design: { ru: 'Дизайн', kg: 'Дизайн' },
    Photography: { ru: 'Фотография', kg: 'Сүрөт тартуу' },
    Cooking: { ru: 'Кулинария', kg: 'Ашкана' },
    Languages: { ru: 'Языки', kg: 'Тилдер' },
    Repair: { ru: 'Ремонт', kg: 'Оңдоо' },
    Collectibles: { ru: 'Коллекции', kg: 'Коллекциялар' },
    Business: { ru: 'Бизнес', kg: 'Бизнес' },
    Travel: { ru: 'Путешествия', kg: 'Саякат' },
    Other: { ru: 'Другое', kg: 'Башка' },
  };
  const getCategoryLabel = (value: string) => {
    if (language === 'en') return value;
    const row = CATEGORY_TRANSLATIONS[value];
    if (!row) return value;
    return language === 'ru' ? row.ru : row.kg;
  };
  const TYPES: { label: string; value: ListingType; icon: string }[] = [
    { label: t('type_book'), value: 'book', icon: 'book-outline' },
    { label: t('type_item'), value: 'item', icon: 'cube-outline' },
    { label: t('type_service'), value: 'service', icon: 'construct-outline' },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4 }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name="close" size={26} color={colors.text} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t('new_listing_title')}</Text>
        <Pressable
          onPress={handleSave}
          disabled={saving}
          style={({ pressed }) => [
            styles.saveBtn,
            { backgroundColor: colors.tint, opacity: pressed || saving ? 0.7 : 1 },
          ]}
        >
          <Text style={styles.saveBtnText}>{saving ? t('saving') : t('post')}</Text>
        </Pressable>
      </View>

      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20, paddingHorizontal: 20 }}
        bottomOffset={20}
      >
        <Text style={[styles.label, { color: colors.text }]}>{t('type')}</Text>
        <View style={styles.typeRow}>
          {TYPES.map(t => (
            <Pressable
              key={t.value}
              onPress={() => { Haptics.selectionAsync(); setType(t.value); }}
              style={[
                styles.typeBtn,
                {
                  backgroundColor: type === t.value ? colors.tint + '15' : colors.surfaceSecondary,
                  borderColor: type === t.value ? colors.tint : colors.border,
                },
              ]}
            >
              <Ionicons
                name={t.icon as any}
                size={20}
                color={type === t.value ? colors.tint : colors.textSecondary}
              />
              <Text style={[
                styles.typeLabel,
                { color: type === t.value ? colors.tint : colors.textSecondary },
              ]}>
                {t.label}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text style={[styles.label, { color: colors.text }]}>{t('title')}</Text>
        <TextInput
          style={[styles.input, { color: colors.text, backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
          value={title}
          onChangeText={setTitle}
          placeholder={t('what_offering')}
          placeholderTextColor={colors.textSecondary}
          maxLength={100}
        />

        <Text style={[styles.label, { color: colors.text }]}>{t('description')}</Text>
        <TextInput
          style={[styles.input, styles.textArea, { color: colors.text, backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
          value={description}
          onChangeText={setDescription}
          placeholder={t('describe_details')}
          placeholderTextColor={colors.textSecondary}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
        />

        <Text style={[styles.label, { color: colors.text }]}>{t('photos')}</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.photosRow}>
          {photos.map((photo, i) => (
            <View key={i} style={styles.photoWrapper}>
              <Image source={{ uri: photo.uri }} style={styles.photo} />
              <Pressable onPress={() => removePhoto(i)} style={styles.photoRemove}>
                <Ionicons name="close-circle" size={22} color="#fff" />
              </Pressable>
            </View>
          ))}
          {photos.length < 5 && (
            <Pressable
              onPress={pickImage}
              style={[styles.addPhotoBtn, { borderColor: colors.border, backgroundColor: colors.surfaceSecondary }]}
            >
              <Ionicons name="camera-outline" size={24} color={colors.textSecondary} />
              <Text style={[styles.addPhotoText, { color: colors.textSecondary }]}>
                {photos.length === 0 ? t('add') : `${photos.length}/5`}
              </Text>
            </Pressable>
          )}
        </ScrollView>

        <Text style={[styles.label, { color: colors.text }]}>{t('category')}</Text>
        <Pressable
          onPress={() => setShowCategories(!showCategories)}
          style={[styles.input, styles.selectRow, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
        >
          <Text style={[styles.selectText, { color: category ? colors.text : colors.textSecondary }]}>
            {category ? getCategoryLabel(category) : t('select_category')}
          </Text>
          <Ionicons name={showCategories ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textSecondary} />
        </Pressable>
        {showCategories && (
          <ScrollView
            style={[styles.categoryList, { backgroundColor: colors.surface, borderColor: colors.border }]}
            nestedScrollEnabled
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator
          >
            {CATEGORIES.map(c => (
              <Pressable
                key={c}
                onPress={() => { setCategory(c); setShowCategories(false); Haptics.selectionAsync(); }}
                style={[styles.categoryItem, { borderBottomColor: colors.border }]}
              >
                <Text style={[styles.categoryItemText, {
                  color: category === c ? colors.tint : colors.text,
                  fontFamily: category === c ? 'Inter_600SemiBold' : 'Inter_400Regular',
                }]}>
                  {getCategoryLabel(c)}
                </Text>
                {category === c && <Ionicons name="checkmark" size={18} color={colors.tint} />}
              </Pressable>
            ))}
          </ScrollView>
        )}

        <Text style={[styles.label, { color: colors.text }]}>{t('what_i_offer')}</Text>
        <TextInput
          style={[styles.input, { color: colors.text, backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
          value={offering}
          onChangeText={setOffering}
          placeholder={t('offer_placeholder')}
          placeholderTextColor={colors.textSecondary}
        />

        <Text style={[styles.label, { color: colors.text }]}>{t('what_i_want')}</Text>
        <TextInput
          style={[styles.input, { color: colors.text, backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
          value={wantInReturn}
          onChangeText={setWantInReturn}
          placeholder={t('want_placeholder')}
          placeholderTextColor={colors.textSecondary}
        />
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Inter_600SemiBold',
  },
  saveBtn: {
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 20,
  },
  saveBtnText: {
    color: '#fff',
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
  scroll: { flex: 1 },
  label: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
    marginBottom: 6,
    marginTop: 16,
  },
  input: {
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
  },
  textArea: {
    minHeight: 100,
  },
  typeRow: {
    flexDirection: 'row',
    gap: 10,
  },
  typeBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  typeLabel: {
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
  },
  photosRow: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  photoWrapper: {
    marginRight: 10,
    position: 'relative',
  },
  photo: {
    width: 80,
    height: 80,
    borderRadius: 10,
  },
  photoRemove: {
    position: 'absolute',
    top: -6,
    right: -6,
  },
  addPhotoBtn: {
    width: 80,
    height: 80,
    borderRadius: 10,
    borderWidth: 1,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  addPhotoText: {
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  selectRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  selectText: {
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
  },
  categoryList: {
    borderWidth: 1,
    borderRadius: 12,
    marginTop: 4,
    maxHeight: 200,
    overflow: 'hidden',
  },
  categoryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderBottomWidth: 0.5,
  },
  categoryItemText: {
    fontSize: 14,
  },
});

