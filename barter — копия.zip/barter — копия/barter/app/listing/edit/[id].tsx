import React, { useState, useEffect } from 'react';
import {
  View, Text, Pressable, TextInput, StyleSheet, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import * as store from '@/lib/storage';
import { CATEGORIES, ListingType } from '@/lib/types';

const TYPES: { label: string; value: ListingType; icon: string }[] = [
  { label: 'Book', value: 'book', icon: 'book-outline' },
  { label: 'Item', value: 'item', icon: 'cube-outline' },
  { label: 'Service', value: 'service', icon: 'construct-outline' },
];

export default function EditListingScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { currentUser } = useData();
  const [type, setType] = useState<ListingType>('item');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [offering, setOffering] = useState('');
  const [wantInReturn, setWantInReturn] = useState('');
  const [showCategories, setShowCategories] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (id) {
      store.getListing(id).then(l => {
        if (l) {
          setType(l.type);
          setTitle(l.title);
          setDescription(l.description);
          setCategory(l.category);
          setOffering(l.offering);
          setWantInReturn(l.wantInReturn);
        }
      });
    }
  }, [id]);

  const handleSave = async () => {
    if (!id || !currentUser) return;
    const listing = await store.getListing(id);
    if (!listing || listing.authorId !== currentUser.id) {
      Alert.alert('Error', 'Only the author can edit');
      return;
    }
    if (!title.trim() || !offering.trim() || !wantInReturn.trim()) {
      Alert.alert('Please fill in all required fields');
      return;
    }
    setSaving(true);
    try {
      await store.updateListing(id, {
        type,
        title: title.trim(),
        description: description.trim(),
        category: category || 'Other',
        offering: offering.trim(),
        wantInReturn: wantInReturn.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (e) {
      Alert.alert('Error', 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const webTopInset = Platform.OS === 'web' ? 20 : 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4 }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name="close" size={26} color={colors.text} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Edit Listing</Text>
        <Pressable
          onPress={handleSave}
          disabled={saving}
          style={({ pressed }) => [
            styles.saveBtn,
            { backgroundColor: colors.tint, opacity: pressed || saving ? 0.7 : 1 },
          ]}
        >
          <Text style={styles.saveBtnText}>{saving ? 'Saving...' : 'Save'}</Text>
        </Pressable>
      </View>

      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20, paddingHorizontal: 20 }}
        bottomOffset={20}
      >
        <Text style={[styles.label, { color: colors.text }]}>Type</Text>
        <View style={styles.typeRow}>
          {TYPES.map(t => (
            <Pressable
              key={t.value}
              onPress={() => { Haptics.selectionAsync(); setType(t.value); }}
              style={[
                styles.typeBtn,
                {
                  backgroundColor: type === t.value ? colors.tint + '15' : colors.surfaceSecondary,
                  borderColor: type === t.value ? colors.tint : colors.border,
                },
              ]}
            >
              <Ionicons name={t.icon as any} size={20} color={type === t.value ? colors.tint : colors.textSecondary} />
              <Text style={[styles.typeLabel, { color: type === t.value ? colors.tint : colors.textSecondary }]}>
                {t.label}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text style={[styles.label, { color: colors.text }]}>Title</Text>
        <TextInput
          style={[styles.input, { color: colors.text, backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
          value={title}
          onChangeText={setTitle}
          placeholder="What are you offering?"
          placeholderTextColor={colors.textSecondary}
        />

        <Text style={[styles.label, { color: colors.text }]}>Description</Text>
        <TextInput
          style={[styles.input, styles.textArea, { color: colors.text, backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
          value={description}
          onChangeText={setDescription}
          placeholder="Details..."
          placeholderTextColor={colors.textSecondary}
          multiline
          textAlignVertical="top"
        />

        <Text style={[styles.label, { color: colors.text }]}>Category</Text>
        <Pressable
          onPress={() => setShowCategories(!showCategories)}
          style={[styles.input, styles.selectRow, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
        >
          <Text style={[styles.selectText, { color: category ? colors.text : colors.textSecondary }]}>
            {category || 'Select category'}
          </Text>
          <Ionicons name={showCategories ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textSecondary} />
        </Pressable>
        {showCategories && (
          <View style={[styles.categoryList, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {CATEGORIES.map(c => (
              <Pressable
                key={c}
                onPress={() => { setCategory(c); setShowCategories(false); }}
                style={[styles.categoryItem, { borderBottomColor: colors.border }]}
              >
                <Text style={[styles.categoryItemText, {
                  color: category === c ? colors.tint : colors.text,
                }]}>{c}</Text>
                {category === c && <Ionicons name="checkmark" size={18} color={colors.tint} />}
              </Pressable>
            ))}
          </View>
        )}

        <Text style={[styles.label, { color: colors.text }]}>What I offer</Text>
        <TextInput
          style={[styles.input, { color: colors.text, backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
          value={offering}
          onChangeText={setOffering}
          placeholder="What you're offering"
          placeholderTextColor={colors.textSecondary}
        />

        <Text style={[styles.label, { color: colors.text }]}>What I want in return</Text>
        <TextInput
          style={[styles.input, { color: colors.text, backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}
          value={wantInReturn}
          onChangeText={setWantInReturn}
          placeholder="What you want"
          placeholderTextColor={colors.textSecondary}
        />
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  headerTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold' },
  saveBtn: { paddingHorizontal: 18, paddingVertical: 8, borderRadius: 20 },
  saveBtnText: { color: '#fff', fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  scroll: { flex: 1 },
  label: { fontSize: 14, fontFamily: 'Inter_600SemiBold', marginBottom: 6, marginTop: 16 },
  input: {
    borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12,
    fontSize: 15, fontFamily: 'Inter_400Regular',
  },
  textArea: { minHeight: 100 },
  typeRow: { flexDirection: 'row', gap: 10 },
  typeBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 12, borderRadius: 12, borderWidth: 1,
  },
  typeLabel: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  selectRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  selectText: { fontSize: 15, fontFamily: 'Inter_400Regular' },
  categoryList: { borderWidth: 1, borderRadius: 12, marginTop: 4, maxHeight: 200 },
  categoryItem: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 0.5,
  },
  categoryItemText: { fontSize: 14, fontFamily: 'Inter_400Regular' },
});
