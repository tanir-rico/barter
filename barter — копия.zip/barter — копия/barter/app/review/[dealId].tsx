import React, { useState, useEffect } from 'react';
import {
  View, Text, Pressable, TextInput, StyleSheet, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useTheme } from '@/context/ThemeContext';
import { useData } from '@/context/DataContext';
import { useLanguage } from '@/context/LanguageContext';
import UserAvatar from '@/components/UserAvatar';
import type { Deal, User, Listing } from '@/lib/types';
import * as store from '@/lib/storage';

export default function ReviewScreen() {
  const { dealId } = useLocalSearchParams<{ dealId: string }>();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t } = useLanguage();
  const { currentUser } = useData();
  const [deal, setDeal] = useState<Deal | null>(null);
  const [otherUser, setOtherUser] = useState<User | null>(null);
  const [listing, setListing] = useState<Listing | null>(null);
  const [rating, setRating] = useState(0);
  const [text, setText] = useState('');
  const [saving, setSaving] = useState(false);
  const [alreadyReviewed, setAlreadyReviewed] = useState(false);

  useEffect(() => {
    loadDeal();
  }, [dealId, currentUser]);

  async function loadDeal() {
    if (!dealId || !currentUser) return;
    const deals = await store.getUserDeals(currentUser.id);
    const d = deals.find(x => x.id === dealId);
    if (!d) return;
    setDeal(d);

    const otherId = d.userAId === currentUser.id ? d.userBId : d.userAId;
    const [u, l] = await Promise.all([store.getUser(otherId), store.getListing(d.listingId)]);
    setOtherUser(u);
    setListing(l);

    const existing = await store.getReviewForDeal(dealId, currentUser.id);
    if (existing) setAlreadyReviewed(true);
  }

  const handleSubmit = async () => {
    if (!deal || !currentUser || !otherUser) return;
    if (rating === 0) {
      Alert.alert(t('review_select_rating'));
      return;
    }

    setSaving(true);
    try {
      const result = await store.createReview({
        dealId: deal.id,
        fromUserId: currentUser.id,
        toUserId: otherUser.id,
        rating,
        text: text.trim(),
      });
      if ('error' in result) {
        Alert.alert(t('error'), result.error);
        return;
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (e) {
      Alert.alert(t('error'), t('review_failed_submit'));
    } finally {
      setSaving(false);
    }
  };

  const webTopInset = Platform.OS === 'web' ? 20 : 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4 }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name="close" size={26} color={colors.text} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t('review_leave_title')}</Text>
        <View style={{ width: 26 }} />
      </View>

      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 20 }}
        bottomOffset={20}
      >
        {alreadyReviewed ? (
          <View style={styles.alreadyReviewed}>
            <Ionicons name="checkmark-circle" size={48} color={colors.success} />
            <Text style={[styles.alreadyText, { color: colors.text }]}>
              {t('review_already_exists')}
            </Text>
          </View>
        ) : (
          <>
            {otherUser && (
              <View style={styles.userSection}>
                <UserAvatar name={otherUser.displayName} avatar={otherUser.avatar} size={60} />
                <Text style={[styles.userName, { color: colors.text }]}>{otherUser.displayName}</Text>
                {listing && (
                  <Text style={[styles.listingName, { color: colors.textSecondary }]}>
                    {listing.title}
                  </Text>
                )}
              </View>
            )}

            <Text style={[styles.ratingLabel, { color: colors.text }]}>{t('review_rating')}</Text>
            <View style={styles.starsRow}>
              {[1, 2, 3, 4, 5].map(s => (
                <Pressable
                  key={s}
                  onPress={() => { setRating(s); Haptics.selectionAsync(); }}
                >
                  <Ionicons
                    name={s <= rating ? 'star' : 'star-outline'}
                    size={40}
                    color={s <= rating ? '#EAB308' : colors.textSecondary}
                  />
                </Pressable>
              ))}
            </View>

            <Text style={[styles.ratingLabel, { color: colors.text, marginTop: 20 }]}>
              {t('review_comment_optional')}
            </Text>
            <TextInput
              style={[styles.textArea, {
                color: colors.text,
                backgroundColor: colors.surfaceSecondary,
                borderColor: colors.border,
              }]}
              value={text}
              onChangeText={setText}
              placeholder={t('review_placeholder')}
              placeholderTextColor={colors.textSecondary}
              multiline
              textAlignVertical="top"
              maxLength={500}
            />

            <Pressable
              onPress={handleSubmit}
              disabled={saving || rating === 0}
              style={({ pressed }) => [
                styles.submitBtn,
                {
                  backgroundColor: rating > 0 ? colors.tint : colors.surfaceSecondary,
                  opacity: pressed || saving ? 0.7 : 1,
                },
              ]}
            >
              <Text style={[styles.submitText, { color: rating > 0 ? '#fff' : colors.textSecondary }]}>
                {saving ? t('review_submitting') : t('review_submit')}
              </Text>
            </Pressable>
          </>
        )}
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  headerTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold' },
  scroll: { flex: 1 },
  userSection: { alignItems: 'center', paddingTop: 20, paddingBottom: 30, gap: 6 },
  userName: { fontSize: 20, fontFamily: 'Inter_700Bold', marginTop: 8 },
  listingName: { fontSize: 14, fontFamily: 'Inter_400Regular' },
  ratingLabel: { fontSize: 15, fontFamily: 'Inter_600SemiBold', marginBottom: 10 },
  starsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
  },
  textArea: {
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    fontFamily: 'Inter_400Regular',
    minHeight: 100,
  },
  submitBtn: {
    marginTop: 24,
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
  },
  submitText: { fontSize: 16, fontFamily: 'Inter_600SemiBold' },
  alreadyReviewed: {
    alignItems: 'center',
    paddingTop: 60,
    gap: 12,
  },
  alreadyText: { fontSize: 18, fontFamily: 'Inter_600SemiBold' },
});
