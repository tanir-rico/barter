import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, Pressable, StyleSheet, Platform, Linking,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import { useTheme } from '@/context/ThemeContext';
import UserAvatar from '@/components/UserAvatar';
import ListingCard from '@/components/ListingCard';
import ReviewCard from '@/components/ReviewCard';
import type { User, Listing, Review } from '@/lib/types';
import * as store from '@/lib/storage';

export default function UserProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const [user, setUser] = useState<User | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [rating, setRating] = useState({ average: 0, count: 0 });
  const [tab, setTab] = useState<'listings' | 'reviews'>('listings');

  useFocusEffect(useCallback(() => {
    if (!id) return;
    Promise.all([
      store.getUser(id),
      store.getUserListings(id),
      store.getUserReviews(id),
      store.getUserRating(id),
    ]).then(([u, l, r, rt]) => {
      setUser(u);
      setListings(l.filter(x => x.status === 'active'));
      setReviews(r);
      setRating(rt);
    });
  }, [id]));

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  if (!user) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.topBar, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4 }]}>
          <Pressable onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </Pressable>
        </View>
        <View style={styles.center}>
          <Text style={[{ color: colors.textSecondary, fontFamily: 'Inter_400Regular', fontSize: 16 }]}>
            User not found
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.topBar, { paddingTop: (Platform.OS === 'web' ? webTopInset : insets.top) + 4 }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </Pressable>
        <Pressable
          onPress={() => router.push({
            pathname: '/complaint',
            params: { targetType: 'user', targetId: user.id },
          })}
        >
          <Ionicons name="flag-outline" size={20} color={colors.textSecondary} />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}>
        <View style={styles.profileHeader}>
          <UserAvatar name={user.displayName} avatar={user.avatar} size={72} />
          <Text style={[styles.name, { color: colors.text }]}>{user.displayName}</Text>
          <Text style={[styles.username, { color: colors.textSecondary }]}>@{user.username}</Text>
          {user.bio ? (
            <Text style={[styles.bio, { color: colors.textSecondary }]}>{user.bio}</Text>
          ) : null}

          <View style={styles.statsRow}>
            <View style={styles.stat}>
              <Text style={[styles.statVal, { color: colors.text }]}>{listings.length}</Text>
              <Text style={[styles.statLbl, { color: colors.textSecondary }]}>Listings</Text>
            </View>
            <View style={[styles.statDiv, { backgroundColor: colors.border }]} />
            <View style={styles.stat}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
                <Ionicons name="star" size={14} color="#EAB308" />
                <Text style={[styles.statVal, { color: colors.text }]}>
                  {rating.average > 0 ? rating.average.toFixed(1) : '-'}
                </Text>
              </View>
              <Text style={[styles.statLbl, { color: colors.textSecondary }]}>
                {rating.count} reviews
              </Text>
            </View>
          </View>

          {user.phone && (
            <Pressable
              onPress={() => Linking.openURL(`tel:${user.phone}`)}
              style={[styles.phoneBtn, { backgroundColor: colors.success + '15' }]}
            >
              <Ionicons name="call" size={18} color={colors.success} />
              <Text style={[styles.phoneBtnText, { color: colors.success }]}>{user.phone}</Text>
            </Pressable>
          )}
        </View>

        <View style={styles.tabRow}>
          {(['listings', 'reviews'] as const).map(t => (
            <Pressable
              key={t}
              onPress={() => setTab(t)}
              style={[styles.tabBtn, { borderBottomColor: tab === t ? colors.tint : 'transparent' }]}
            >
              <Text style={[styles.tabText, { color: tab === t ? colors.tint : colors.textSecondary }]}>
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.tabContent}>
          {tab === 'listings' && (
            listings.length === 0 ? (
              <View style={styles.empty}>
                <Ionicons name="pricetag-outline" size={32} color={colors.textSecondary} />
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>No active listings</Text>
              </View>
            ) : (
              listings.map(l => (
                <ListingCard
                  key={l.id}
                  listing={l}
                  compact
                  onPress={() => router.push({ pathname: '/listing/[id]', params: { id: l.id } })}
                />
              ))
            )
          )}
          {tab === 'reviews' && (
            reviews.length === 0 ? (
              <View style={styles.empty}>
                <Ionicons name="star-outline" size={32} color={colors.textSecondary} />
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>No reviews yet</Text>
              </View>
            ) : (
              reviews.map(r => <ReviewCard key={r.id} review={r} />)
            )
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  profileHeader: {
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 8,
    gap: 4,
  },
  name: { fontSize: 22, fontFamily: 'Inter_700Bold', marginTop: 10 },
  username: { fontSize: 14, fontFamily: 'Inter_400Regular' },
  bio: { fontSize: 14, fontFamily: 'Inter_400Regular', textAlign: 'center', marginTop: 6, lineHeight: 20 },
  statsRow: { flexDirection: 'row', alignItems: 'center', gap: 20, marginTop: 16 },
  stat: { alignItems: 'center' },
  statVal: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  statLbl: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  statDiv: { width: 1, height: 30 },
  phoneBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginTop: 14,
  },
  phoneBtnText: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  tabRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 20,
    marginTop: 20,
    marginBottom: 16,
  },
  tabBtn: { paddingBottom: 8, borderBottomWidth: 2 },
  tabText: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  tabContent: { paddingHorizontal: 20 },
  empty: { alignItems: 'center', paddingVertical: 40, gap: 8 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular' },
});
