import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '@/context/ThemeContext';
import { useLanguage } from '@/context/LanguageContext';
import type { Listing } from '@/lib/types';

const TYPE_ICONS: Record<string, { name: any; family: 'ion' | 'mci' }> = {
  book: { name: 'book-outline', family: 'ion' },
  item: { name: 'cube-outline', family: 'ion' },
  service: { name: 'hand-heart-outline', family: 'mci' },
};

interface Props {
  listing: Listing;
  onPress: () => void;
  compact?: boolean;
}

export default function ListingCard({ listing, onPress, compact }: Props) {
  const { colors, isDark } = useTheme();
  const { t, language } = useLanguage();
  const typeIcon = TYPE_ICONS[listing.type] || TYPE_ICONS.item;

  const typeColor = listing.type === 'book' ? '#3B82F6' : listing.type === 'service' ? colors.tint : colors.accent;
  const CATEGORY_TRANSLATIONS: Record<string, { ru: string; kg: string }> = {
    Fiction: { ru: 'Художественная литература', kg: 'Көркөм адабият' },
    'Non-Fiction': { ru: 'Нон-фикшн', kg: 'Нон-фикшн' },
    Science: { ru: 'Наука', kg: 'Илим' },
    Technology: { ru: 'Технологии', kg: 'Технология' },
    Art: { ru: 'Искусство', kg: 'Өнөр' },
    Music: { ru: 'Музыка', kg: 'Музыка' },
    Sports: { ru: 'Спорт', kg: 'Спорт' },
    Clothing: { ru: 'Одежда', kg: 'Кийим' },
    Electronics: { ru: 'Электроника', kg: 'Электроника' },
    Furniture: { ru: 'Мебель', kg: 'Эмерек' },
    'Home & Garden': { ru: 'Дом и сад', kg: 'Үй жана бакча' },
    Auto: { ru: 'Авто', kg: 'Авто' },
    'Games & Toys': { ru: 'Игры и игрушки', kg: 'Оюндар жана оюнчуктар' },
    Pets: { ru: 'Питомцы', kg: 'Үй жаныбарлары' },
    'Baby & Kids': { ru: 'Для детей', kg: 'Балдар үчүн' },
    'Health & Beauty': { ru: 'Здоровье и красота', kg: 'Ден соолук жана сулуулук' },
    Education: { ru: 'Образование', kg: 'Билим берүү' },
    Design: { ru: 'Дизайн', kg: 'Дизайн' },
    Photography: { ru: 'Фотография', kg: 'Сүрөт тартуу' },
    Cooking: { ru: 'Кулинария', kg: 'Ашкана' },
    Languages: { ru: 'Языки', kg: 'Тилдер' },
    Repair: { ru: 'Ремонт', kg: 'Оңдоо' },
    Collectibles: { ru: 'Коллекции', kg: 'Коллекциялар' },
    Business: { ru: 'Бизнес', kg: 'Бизнес' },
    Travel: { ru: 'Путешествия', kg: 'Саякат' },
    Other: { ru: 'Другое', kg: 'Башка' },
  };
  const getCategoryLabel = (value: string) => {
    if (language === 'en') return value;
    const row = CATEGORY_TRANSLATIONS[value];
    if (!row) return value;
    return language === 'ru' ? row.ru : row.kg;
  };
  const typeLabelMap: Record<string, string> = {
    book: t('type_book'),
    item: t('type_item'),
    service: t('type_service'),
  };

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          opacity: pressed ? 0.92 : 1,
          transform: [{ scale: pressed ? 0.98 : 1 }],
          ...Platform.select({
            ios: {
              shadowColor: colors.cardShadow,
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 1,
              shadowRadius: 12,
            },
            android: { elevation: 3 },
            default: {},
          }),
        },
        compact && styles.cardCompact,
      ]}
    >
      <View style={[styles.typeTag, { backgroundColor: typeColor + '18' }]}>
        {typeIcon.family === 'ion' ? (
          <Ionicons name={typeIcon.name} size={14} color={typeColor} />
        ) : (
          <MaterialCommunityIcons name={typeIcon.name} size={14} color={typeColor} />
        )}
        <Text style={[styles.typeText, { color: typeColor }]}>
          {typeLabelMap[listing.type] || listing.type}
        </Text>
      </View>

      <Text style={[styles.title, { color: colors.text }]} numberOfLines={2}>
        {listing.title}
      </Text>

      {!compact && (
        <Text style={[styles.description, { color: colors.textSecondary }]} numberOfLines={2}>
          {listing.description}
        </Text>
      )}

      <View style={styles.exchangeRow}>
        <View style={[styles.exchangeBox, { backgroundColor: colors.tint + '10' }]}>
          <Ionicons name="arrow-up-circle-outline" size={14} color={colors.tint} />
          <Text style={[styles.exchangeText, { color: colors.tint }]} numberOfLines={1}>
            {listing.offering}
          </Text>
        </View>
        <Ionicons name="swap-horizontal" size={16} color={colors.textSecondary} />
        <View style={[styles.exchangeBox, { backgroundColor: colors.accent + '10' }]}>
          <Ionicons name="arrow-down-circle-outline" size={14} color={colors.accent} />
          <Text style={[styles.exchangeText, { color: colors.accent }]} numberOfLines={1}>
            {listing.wantInReturn}
          </Text>
        </View>
      </View>

      <View style={styles.footer}>
        <View style={[styles.categoryPill, { backgroundColor: colors.surfaceSecondary }]}>
          <Text style={[styles.categoryText, { color: colors.textSecondary }]}>
            {getCategoryLabel(listing.category)}
          </Text>
        </View>
        {listing.status === 'closed' && (
          <View style={[styles.statusPill, { backgroundColor: colors.success + '20' }]}>
            <Text style={[styles.statusText, { color: colors.success }]}>{t('status_closed')}</Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    marginBottom: 12,
  },
  cardCompact: {
    padding: 12,
    marginBottom: 8,
  },
  typeTag: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    gap: 4,
    marginBottom: 10,
  },
  typeText: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
  },
  title: {
    fontSize: 17,
    fontFamily: 'Inter_600SemiBold',
    lineHeight: 22,
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    lineHeight: 20,
    marginBottom: 12,
  },
  exchangeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  exchangeBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 8,
  },
  exchangeText: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    flex: 1,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  categoryPill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoryText: {
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  statusPill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
  },
});
