import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useTheme } from '@/context/ThemeContext';
import UserAvatar from '@/components/UserAvatar';
import type { Review, User } from '@/lib/types';
import * as store from '@/lib/storage';

interface Props {
  review: Review;
}

export default function ReviewCard({ review }: Props) {
  const { colors } = useTheme();
  const [fromUser, setFromUser] = useState<User | null>(null);

  useEffect(() => {
    store.getUser(review.fromUserId).then(setFromUser);
  }, [review.fromUserId]);

  const stars = Array.from({ length: 5 }, (_, i) => i < review.rating);
  const timeAgo = getTimeAgo(review.createdAt);

  return (
    <Pressable
      onPress={() => router.push({ pathname: '/user/[id]', params: { id: review.fromUserId } })}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          opacity: pressed ? 0.9 : 1,
        },
      ]}
    >
      <View style={styles.header}>
        <UserAvatar name={fromUser?.displayName || '?'} avatar={fromUser?.avatar} size={36} />
        <View style={styles.headerInfo}>
          <Text style={[styles.name, { color: colors.text }]}>
            {fromUser?.displayName || 'User'}
          </Text>
          <Text style={[styles.time, { color: colors.textSecondary }]}>{timeAgo}</Text>
        </View>
        <View style={styles.stars}>
          {stars.map((filled, i) => (
            <Ionicons
              key={i}
              name={filled ? 'star' : 'star-outline'}
              size={14}
              color={filled ? '#EAB308' : colors.textSecondary}
            />
          ))}
        </View>
      </View>
      {review.text ? (
        <Text style={[styles.text, { color: colors.text }]}>{review.text}</Text>
      ) : null}
    </Pressable>
  );
}

function getTimeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

const styles = StyleSheet.create({
  card: {
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  headerInfo: {
    flex: 1,
  },
  name: {
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
  time: {
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
  },
  stars: {
    flexDirection: 'row',
    gap: 2,
  },
  text: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    lineHeight: 20,
    marginTop: 10,
  },
});
