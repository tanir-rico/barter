import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Image } from 'expo-image';
import { useTheme } from '@/context/ThemeContext';

interface Props {
  name: string;
  avatar?: string | null;
  size?: number;
}

export default function UserAvatar({ name, avatar, size = 40 }: Props) {
  const { colors } = useTheme();
  const initial = (name || '?')[0].toUpperCase();

  if (avatar) {
    return (
      <Image
        source={{ uri: avatar }}
        style={[styles.image, { width: size, height: size, borderRadius: size / 2 }]}
      />
    );
  }

  return (
    <View style={[
      styles.placeholder,
      {
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: colors.tint + '20',
      },
    ]}>
      <Text style={[styles.initial, { color: colors.tint, fontSize: size * 0.4 }]}>
        {initial}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  image: {
    overflow: 'hidden',
  },
  placeholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  initial: {
    fontFamily: 'Inter_700Bold',
  },
});
