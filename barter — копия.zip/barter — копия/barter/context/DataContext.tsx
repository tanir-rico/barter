import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, ReactNode } from 'react';
import type { User } from '@/lib/types';
import * as store from '@/lib/storage';

interface DataContextValue {
  currentUser: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  refreshUser: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  register: (data: { email: string; username: string; displayName: string; password: string }) => Promise<{ error?: string }>;
  logout: () => Promise<void>;
}

const DataContext = createContext<DataContextValue | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    initUser();
  }, []);

  async function initUser() {
    try {
      await store.removeLegacyDemoData();
      const user = await store.getCurrentUser();
      if (user) {
        setCurrentUser(user);
      }
    } catch (e) {
      console.error('Failed to init user:', e);
    } finally {
      setIsLoading(false);
    }
  }

  const refreshUser = useCallback(async () => {
    const user = await store.getCurrentUser();
    setCurrentUser(user);
  }, []);

  const updateProfile = useCallback(async (data: Partial<User>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...data };
    await store.setCurrentUser(updated);
    const fresh = await store.getCurrentUser();
    setCurrentUser(fresh || updated);
  }, [currentUser]);

  const login = useCallback(async (email: string, password: string) => {
    const result = await store.loginUser(email, password);
    if ('error' in result) {
      return { error: result.error };
    }
    setCurrentUser(result);
    return {};
  }, []);

  const register = useCallback(async (data: { email: string; username: string; displayName: string; password: string }) => {
    const result = await store.registerUser(data);
    if ('error' in result) {
      return { error: result.error };
    }
    setCurrentUser(result);
    return {};
  }, []);

  const logout = useCallback(async () => {
    await store.logoutUser();
    setCurrentUser(null);
  }, []);

  const value = useMemo(() => ({
    currentUser,
    isLoading,
    isAuthenticated: !!currentUser,
    refreshUser,
    updateProfile,
    login,
    register,
    logout,
  }), [currentUser, isLoading, refreshUser, updateProfile, login, register, logout]);

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
