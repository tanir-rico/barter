import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';
import * as FileSystem from 'expo-file-system/legacy';
import { Buffer } from 'buffer';
import type { User as SupabaseAuthUser } from '@supabase/supabase-js';
import type {
  User, Listing, ChatRoom, Message, Deal, Review, Complaint, AdminActionLog,
  ListingType, ListingStatus, DealStatus, UserStatus,
} from './types';
import { getSupabaseConfigError, supabase } from './supabase';

const KEYS = {
  users: 'swaphub_users',
  listings: 'swaphub_listings',
  chatRooms: 'swaphub_chatrooms',
  messages: 'swaphub_messages',
  deals: 'swaphub_deals',
  reviews: 'swaphub_reviews',
  complaints: 'swaphub_complaints',
  theme: 'swaphub_theme',
  language: 'swaphub_language',
  demoCleanupDone: 'swaphub_demo_cleanup_done_v1',
};

const DEMO_USERNAMES = new Set(['alex_books', 'maria_craft', 'james_tech']);
const DEMO_LISTING_TITLES = new Set([
  'The Great Gatsby',
  'Vintage Camera',
  'Web Development Tutoring',
  '1984 by George Orwell',
  'Acoustic Guitar',
  'Graphic Design Help',
]);

const PROFILE_SELECT = 'id, username, display_name, avatar, phone, bio, blocked, is_admin, status, created_at';
const COMPLAINT_SELECT = 'id, from_user_id, target_type, target_id, reason, description, status, reviewed_by, reviewed_at, resolution_note, created_at';

type ProfileRow = {
  id: string;
  username: string;
  display_name: string;
  avatar: string | null;
  phone: string | null;
  bio: string | null;
  blocked: boolean | null;
  is_admin: boolean | null;
  status: UserStatus | null;
  created_at: string;
};

type ListingRow = {
  id: string;
  author_id: string;
  type: ListingType;
  title: string;
  description: string;
  photos: string[] | null;
  category: string;
  offering: string;
  want_in_return: string;
  status: ListingStatus;
  created_at: string;
};

type ChatRoomRow = {
  id: string;
  listing_id: string;
  user_a_id: string;
  user_b_id: string;
  created_at: string;
  last_message_at: string;
};

type MessageRow = {
  id: string;
  chat_room_id: string;
  sender_id: string;
  text: string | null;
  image_url: string | null;
  created_at: string;
};

type DealRow = {
  id: string;
  listing_id: string;
  chat_room_id: string;
  proposed_by: string;
  user_a_id: string;
  user_b_id: string;
  status: DealStatus;
  created_at: string;
};

type ReviewRow = {
  id: string;
  deal_id: string;
  from_user_id: string;
  to_user_id: string;
  rating: number;
  text: string;
  created_at: string;
};

type ComplaintRow = {
  id: string;
  from_user_id: string;
  target_type: 'listing' | 'user';
  target_id: string;
  reason: string;
  description: string;
  status: 'new' | 'in_review' | 'resolved' | 'rejected';
  reviewed_by: string | null;
  reviewed_at: string | null;
  resolution_note: string | null;
  created_at: string;
};

type AdminActionRow = {
  id: string;
  admin_id: string;
  target_type: 'user' | 'listing' | 'complaint';
  target_id: string;
  action: string;
  details: Record<string, unknown> | null;
  created_at: string;
};

function genId(): string {
  return Crypto.randomUUID();
}

async function getAll<T>(key: string): Promise<T[]> {
  const raw = await AsyncStorage.getItem(key);
  return raw ? JSON.parse(raw) : [];
}

async function saveAll<T>(key: string, items: T[]): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(items));
}

export async function getTheme(): Promise<'light' | 'dark' | null> {
  const t = await AsyncStorage.getItem(KEYS.theme);
  return t as 'light' | 'dark' | null;
}

export async function setTheme(theme: 'light' | 'dark'): Promise<void> {
  await AsyncStorage.setItem(KEYS.theme, theme);
}

export async function getLanguage(): Promise<'en' | 'ru' | 'kg' | null> {
  const lang = await AsyncStorage.getItem(KEYS.language);
  if (lang === 'en' || lang === 'ru' || lang === 'kg') {
    return lang;
  }
  return null;
}

export async function setLanguage(language: 'en' | 'ru' | 'kg'): Promise<void> {
  await AsyncStorage.setItem(KEYS.language, language);
}

function toUser(profile: ProfileRow): User {
  const status = profile.status || 'active';
  return {
    id: profile.id,
    username: profile.username,
    displayName: profile.display_name,
    avatar: profile.avatar,
    phone: profile.phone,
    bio: profile.bio || '',
    createdAt: Date.parse(profile.created_at) || Date.now(),
    blocked: Boolean(profile.blocked) || status === 'banned',
    isAdmin: Boolean(profile.is_admin),
    status,
  };
}

function normalizeUsername(username: string): string {
  return username.trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '_');
}

function requireSupabase() {
  if (!supabase) {
    throw new Error(getSupabaseConfigError());
  }
  return supabase;
}

function toListing(row: ListingRow): Listing {
  return {
    id: row.id,
    authorId: row.author_id,
    type: row.type,
    title: row.title,
    description: row.description,
    photos: row.photos || [],
    category: row.category,
    offering: row.offering,
    wantInReturn: row.want_in_return,
    status: row.status,
    createdAt: Date.parse(row.created_at) || Date.now(),
  };
}

function toChatRoom(row: ChatRoomRow): ChatRoom {
  return {
    id: row.id,
    listingId: row.listing_id,
    userAId: row.user_a_id,
    userBId: row.user_b_id,
    createdAt: Date.parse(row.created_at) || Date.now(),
    lastMessageAt: Date.parse(row.last_message_at) || Date.now(),
  };
}

function toMessage(row: MessageRow): Message {
  return {
    id: row.id,
    chatRoomId: row.chat_room_id,
    senderId: row.sender_id,
    text: row.text || '',
    imageUrl: row.image_url,
    createdAt: Date.parse(row.created_at) || Date.now(),
  };
}

function toDeal(row: DealRow): Deal {
  return {
    id: row.id,
    listingId: row.listing_id,
    chatRoomId: row.chat_room_id,
    proposedBy: row.proposed_by,
    userAId: row.user_a_id,
    userBId: row.user_b_id,
    status: row.status,
    createdAt: Date.parse(row.created_at) || Date.now(),
  };
}

function toReview(row: ReviewRow): Review {
  return {
    id: row.id,
    dealId: row.deal_id,
    fromUserId: row.from_user_id,
    toUserId: row.to_user_id,
    rating: row.rating,
    text: row.text,
    createdAt: Date.parse(row.created_at) || Date.now(),
  };
}

function toComplaint(row: ComplaintRow): Complaint {
  return {
    id: row.id,
    fromUserId: row.from_user_id,
    targetType: row.target_type,
    targetId: row.target_id,
    reason: row.reason,
    description: row.description,
    status: row.status,
    reviewedBy: row.reviewed_by,
    reviewedAt: row.reviewed_at ? (Date.parse(row.reviewed_at) || null) : null,
    resolutionNote: row.resolution_note,
    createdAt: Date.parse(row.created_at) || Date.now(),
  };
}

function toAdminActionLog(row: AdminActionRow): AdminActionLog {
  return {
    id: row.id,
    adminId: row.admin_id,
    targetType: row.target_type,
    targetId: row.target_id,
    action: row.action,
    details: row.details || {},
    createdAt: Date.parse(row.created_at) || Date.now(),
  };
}

function sortUserPair(userAId: string, userBId: string): [string, string] {
  return userAId < userBId ? [userAId, userBId] : [userBId, userAId];
}

function getUsernameFromAuthUser(authUser: SupabaseAuthUser): string {
  const metaUsername = typeof authUser.user_metadata?.username === 'string'
    ? authUser.user_metadata.username
    : '';
  if (metaUsername.trim()) {
    return normalizeUsername(metaUsername);
  }

  const emailPrefix = authUser.email?.split('@')[0] || '';
  if (emailPrefix.trim()) {
    return normalizeUsername(emailPrefix);
  }

  return `user_${authUser.id.slice(0, 8)}`;
}

function getDisplayNameFromAuthUser(authUser: SupabaseAuthUser): string {
  const metaName = typeof authUser.user_metadata?.display_name === 'string'
    ? authUser.user_metadata.display_name
    : '';
  if (metaName.trim()) {
    return metaName.trim();
  }

  const emailPrefix = authUser.email?.split('@')[0];
  return emailPrefix || 'SwapHub User';
}

async function getProfileById(userId: string): Promise<ProfileRow | null> {
  if (!supabase) return null;

  const { data, error } = await supabase
    .from('profiles')
    .select(PROFILE_SELECT)
    .eq('id', userId)
    .maybeSingle();

  if (error) {
    console.error('Failed to fetch profile:', error.message);
    return null;
  }

  return data;
}

async function createProfileFromAuthUser(authUser: SupabaseAuthUser): Promise<ProfileRow | null> {
  if (!supabase) return null;

  const username = getUsernameFromAuthUser(authUser);
  const displayName = getDisplayNameFromAuthUser(authUser);
  const createdAt = new Date().toISOString();

  const { data, error } = await supabase
    .from('profiles')
    .upsert({
      id: authUser.id,
      username,
      display_name: displayName,
      avatar: null,
      phone: null,
      bio: '',
      blocked: false,
      status: 'active',
      created_at: createdAt,
    }, { onConflict: 'id' })
    .select(PROFILE_SELECT)
    .single();

  if (error) {
    console.error('Failed to create profile:', error.message);
    return null;
  }

  return data;
}

async function getOrCreateProfile(authUser: SupabaseAuthUser): Promise<ProfileRow | null> {
  const existing = await getProfileById(authUser.id);
  if (existing) {
    return existing;
  }

  return createProfileFromAuthUser(authUser);
}

async function requireAuthenticatedUserId(): Promise<string> {
  const db = requireSupabase();
  const { data, error } = await db.auth.getUser();
  if (error || !data.user) {
    throw new Error('Not authenticated');
  }
  return data.user.id;
}

async function ensureUserCanAct(userId: string): Promise<void> {
  const profile = await getProfileById(userId);
  if (!profile) {
    throw new Error('Profile not found');
  }
  const status = profile.status || 'active';
  if (status === 'banned') {
    throw new Error('Your account is banned');
  }
  if (status === 'deleted') {
    throw new Error('Your account is deleted');
  }
}

export async function getCurrentUser(): Promise<User | null> {
  if (!supabase) {
    return null;
  }

  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) {
    return null;
  }

  const profile = await getOrCreateProfile(data.user);
  if (!profile) {
    return null;
  }

  return toUser(profile);
}

export async function setCurrentUser(user: User): Promise<void> {
  if (!supabase) {
    throw new Error(getSupabaseConfigError());
  }

  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) {
    throw new Error('Not authenticated');
  }

  const { data: updated, error: updateError } = await supabase
    .from('profiles')
    .upsert({
      id: data.user.id,
      username: normalizeUsername(user.username),
      display_name: user.displayName.trim(),
      avatar: user.avatar,
      phone: user.phone,
      bio: user.bio || '',
    }, { onConflict: 'id' })
    .select(PROFILE_SELECT)
    .single();

  if (updateError) {
    throw new Error(updateError.message);
  }
}

export async function registerUser(data: {
  email: string;
  username: string;
  displayName: string;
  password: string;
}): Promise<User | { error: string }> {
  if (!supabase) {
    return { error: getSupabaseConfigError() };
  }

  const email = data.email.trim().toLowerCase();
  const username = normalizeUsername(data.username);
  const displayName = data.displayName.trim();

  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return { error: 'Enter a valid email' };
  }
  if (username.length < 3) {
    return { error: 'Username must be at least 3 characters' };
  }
  if (data.password.length < 6) {
    return { error: 'Password must be at least 6 characters' };
  }
  if (!displayName) {
    return { error: 'Display name is required' };
  }

  const { data: existingProfile, error: existingError } = await supabase
    .from('profiles')
    .select('id')
    .eq('username', username)
    .maybeSingle();

  if (existingError) {
    return { error: existingError.message };
  }
  if (existingProfile) {
    return { error: 'Username is already taken' };
  }

  const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
    email,
    password: data.password,
    options: {
      data: {
        username,
        display_name: displayName,
      },
    },
  });

  if (signUpError) {
    return { error: signUpError.message };
  }

  if (!signUpData.user) {
    return { error: 'Registration failed, no user returned' };
  }

  if (!signUpData.session) {
    return { error: 'Confirm your email, then sign in' };
  }

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .upsert({
      id: signUpData.user.id,
      username,
      display_name: displayName,
      avatar: null,
      phone: null,
      bio: '',
      blocked: false,
      status: 'active',
    }, { onConflict: 'id' })
    .select(PROFILE_SELECT)
    .single();

  if (profileError) {
    return { error: profileError.message };
  }

  return toUser(profile);
}

export async function loginUser(email: string, password: string): Promise<User | { error: string }> {
  if (!supabase) {
    return { error: getSupabaseConfigError() };
  }

  const normalizedEmail = email.trim().toLowerCase();
  if (!normalizedEmail) {
    return { error: 'Email is required' };
  }
  if (!password) {
    return { error: 'Password is required' };
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email: normalizedEmail,
    password,
  });

  if (error || !data.user) {
    return { error: error?.message || 'Invalid email or password' };
  }

  const profile = await getOrCreateProfile(data.user);
  if (!profile) {
    return { error: 'Failed to load user profile' };
  }

  const user = toUser(profile);
  if (user.status === 'banned' || user.blocked) {
    await supabase.auth.signOut();
    return { error: 'This account has been banned' };
  }
  if (user.status === 'deleted') {
    await supabase.auth.signOut();
    return { error: 'This account has been deleted' };
  }

  return user;
}

export async function logoutUser(): Promise<void> {
  if (supabase) {
    await supabase.auth.signOut();
  }
}

export async function getUser(id: string): Promise<User | null> {
  const profile = await getProfileById(id);
  if (!profile) {
    return null;
  }

  return toUser(profile);
}

export async function getAllUsers(): Promise<User[]> {
  if (!supabase) {
    return [];
  }

  const { data, error } = await supabase
    .from('profiles')
    .select(PROFILE_SELECT)
    .order('created_at', { ascending: false })
    .limit(200);

  if (error || !data) {
    console.error('Failed to load users:', error?.message);
    return [];
  }

  return data.map(toUser);
}

export async function removeLegacyDemoData(): Promise<void> {
  const cleanupFlag = await AsyncStorage.getItem(KEYS.demoCleanupDone);
  if (cleanupFlag === '1') {
    return;
  }

  const users = await getAll<User>(KEYS.users);
  const demoUserIds = new Set(
    users.filter((u) => DEMO_USERNAMES.has(u.username)).map((u) => u.id),
  );
  const cleanUsers = users.filter((u) => !DEMO_USERNAMES.has(u.username));

  const listings = await getAll<Listing>(KEYS.listings);
  const cleanListings = listings.filter(
    (l) => !demoUserIds.has(l.authorId) && !DEMO_LISTING_TITLES.has(l.title),
  );
  const removedListingIds = new Set(
    listings.filter((l) => !cleanListings.some((x) => x.id === l.id)).map((l) => l.id),
  );

  const chatRooms = await getAll<ChatRoom>(KEYS.chatRooms);
  const cleanChatRooms = chatRooms.filter(
    (r) => !removedListingIds.has(r.listingId) && !demoUserIds.has(r.userAId) && !demoUserIds.has(r.userBId),
  );
  const removedChatRoomIds = new Set(
    chatRooms.filter((r) => !cleanChatRooms.some((x) => x.id === r.id)).map((r) => r.id),
  );

  const messages = await getAll<Message>(KEYS.messages);
  const cleanMessages = messages.filter(
    (m) => !removedChatRoomIds.has(m.chatRoomId) && !demoUserIds.has(m.senderId),
  );

  const deals = await getAll<Deal>(KEYS.deals);
  const cleanDeals = deals.filter(
    (d) => !removedListingIds.has(d.listingId)
      && !removedChatRoomIds.has(d.chatRoomId)
      && !demoUserIds.has(d.userAId)
      && !demoUserIds.has(d.userBId)
      && !demoUserIds.has(d.proposedBy),
  );
  const removedDealIds = new Set(
    deals.filter((d) => !cleanDeals.some((x) => x.id === d.id)).map((d) => d.id),
  );

  const reviews = await getAll<Review>(KEYS.reviews);
  const cleanReviews = reviews.filter(
    (r) => !removedDealIds.has(r.dealId) && !demoUserIds.has(r.fromUserId) && !demoUserIds.has(r.toUserId),
  );

  const complaints = await getAll<Complaint>(KEYS.complaints);
  const cleanComplaints = complaints.filter(
    (c) => !demoUserIds.has(c.fromUserId)
      && !(c.targetType === 'user' && demoUserIds.has(c.targetId))
      && !(c.targetType === 'listing' && removedListingIds.has(c.targetId)),
  );

  void cleanUsers;
  await saveAll(KEYS.listings, cleanListings);
  await saveAll(KEYS.chatRooms, cleanChatRooms);
  await saveAll(KEYS.messages, cleanMessages);
  await saveAll(KEYS.deals, cleanDeals);
  await saveAll(KEYS.reviews, cleanReviews);
  await saveAll(KEYS.complaints, cleanComplaints);
  await AsyncStorage.removeItem(KEYS.users);
  await AsyncStorage.setItem(KEYS.demoCleanupDone, '1');
}

export async function createListing(data: {
  authorId: string;
  type: ListingType;
  title: string;
  description: string;
  photos: string[];
  category: string;
  offering: string;
  wantInReturn: string;
}): Promise<Listing> {
  const db = requireSupabase();
  const authUserId = await requireAuthenticatedUserId();
  if (authUserId !== data.authorId) {
    throw new Error('You can create listings only for yourself');
  }
  await ensureUserCanAct(authUserId);

  const { data: row, error } = await db
    .from('listings')
    .insert({
      author_id: data.authorId,
      type: data.type,
      title: data.title,
      description: data.description,
      photos: data.photos,
      category: data.category,
      offering: data.offering,
      want_in_return: data.wantInReturn,
      status: 'active',
    })
    .select('id, author_id, type, title, description, photos, category, offering, want_in_return, status, created_at')
    .single();

  if (error || !row) {
    throw new Error(error?.message || 'Failed to create listing');
  }

  return toListing(row as ListingRow);
}

export async function updateListing(id: string, data: Partial<Listing>): Promise<Listing | null> {
  const db = requireSupabase();
  const payload: Record<string, unknown> = {};
  if (data.type) payload.type = data.type;
  if (data.title !== undefined) payload.title = data.title;
  if (data.description !== undefined) payload.description = data.description;
  if (data.photos !== undefined) payload.photos = data.photos;
  if (data.category !== undefined) payload.category = data.category;
  if (data.offering !== undefined) payload.offering = data.offering;
  if (data.wantInReturn !== undefined) payload.want_in_return = data.wantInReturn;
  if (data.status !== undefined) payload.status = data.status;

  const { data: row, error } = await db
    .from('listings')
    .update(payload)
    .eq('id', id)
    .select('id, author_id, type, title, description, photos, category, offering, want_in_return, status, created_at')
    .maybeSingle();

  if (error) {
    throw new Error(error.message);
  }

  return row ? toListing(row as ListingRow) : null;
}

export async function deleteListing(id: string): Promise<void> {
  const db = requireSupabase();
  const { error } = await db
    .from('listings')
    .update({ status: 'deleted' })
    .eq('id', id);
  if (error) {
    throw new Error(error.message);
  }
}

export async function getAllListings(): Promise<Listing[]> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('listings')
    .select('id, author_id, type, title, description, photos, category, offering, want_in_return, status, created_at')
    .in('status', ['active', 'closed'])
    .order('created_at', { ascending: false });

  if (error || !data) {
    console.error('Failed to load listings:', error?.message);
    return [];
  }

  return (data as ListingRow[]).map(toListing);
}

export async function getListing(id: string): Promise<Listing | null> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('listings')
    .select('id, author_id, type, title, description, photos, category, offering, want_in_return, status, created_at')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    console.error('Failed to load listing:', error.message);
    return null;
  }

  return data ? toListing(data as ListingRow) : null;
}

export async function getUserListings(userId: string): Promise<Listing[]> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('listings')
    .select('id, author_id, type, title, description, photos, category, offering, want_in_return, status, created_at')
    .eq('author_id', userId)
    .in('status', ['active', 'closed'])
    .order('created_at', { ascending: false });

  if (error || !data) {
    console.error('Failed to load user listings:', error?.message);
    return [];
  }

  return (data as ListingRow[]).map(toListing);
}

export async function getOrCreateChatRoom(listingId: string, userAId: string, userBId: string): Promise<ChatRoom> {
  const db = requireSupabase();
  const [leftId, rightId] = sortUserPair(userAId, userBId);

  const { data: existing, error: findError } = await db
    .from('chat_rooms')
    .select('id, listing_id, user_a_id, user_b_id, created_at, last_message_at')
    .eq('listing_id', listingId)
    .eq('user_a_id', leftId)
    .eq('user_b_id', rightId)
    .maybeSingle();

  if (findError) {
    throw new Error(findError.message);
  }
  if (existing) {
    return toChatRoom(existing as ChatRoomRow);
  }

  const { data: created, error: createError } = await db
    .from('chat_rooms')
    .insert({
      listing_id: listingId,
      user_a_id: leftId,
      user_b_id: rightId,
      last_message_at: new Date().toISOString(),
    })
    .select('id, listing_id, user_a_id, user_b_id, created_at, last_message_at')
    .single();

  if (createError || !created) {
    // Handle race condition: another request created the same room between select and insert.
    const { data: afterConflict, error: afterConflictError } = await db
      .from('chat_rooms')
      .select('id, listing_id, user_a_id, user_b_id, created_at, last_message_at')
      .eq('listing_id', listingId)
      .eq('user_a_id', leftId)
      .eq('user_b_id', rightId)
      .maybeSingle();

    if (!afterConflictError && afterConflict) {
      return toChatRoom(afterConflict as ChatRoomRow);
    }

    throw new Error(createError?.message || 'Failed to create chat room');
  }

  return toChatRoom(created as ChatRoomRow);
}

export async function getUserChatRooms(userId: string): Promise<ChatRoom[]> {
  const db = requireSupabase();
  const [left, right] = await Promise.all([
    db
      .from('chat_rooms')
      .select('id, listing_id, user_a_id, user_b_id, created_at, last_message_at')
      .eq('user_a_id', userId),
    db
      .from('chat_rooms')
      .select('id, listing_id, user_a_id, user_b_id, created_at, last_message_at')
      .eq('user_b_id', userId),
  ]);

  if (left.error || right.error) {
    console.error('Failed to load chat rooms:', left.error?.message || right.error?.message);
    return [];
  }

  const dedup = new Map<string, ChatRoom>();
  for (const row of [...(left.data || []), ...(right.data || [])] as ChatRoomRow[]) {
    dedup.set(row.id, toChatRoom(row));
  }

  return Array.from(dedup.values()).sort((a, b) => b.lastMessageAt - a.lastMessageAt);
}

export async function getChatRoom(id: string): Promise<ChatRoom | null> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('chat_rooms')
    .select('id, listing_id, user_a_id, user_b_id, created_at, last_message_at')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    console.error('Failed to load chat room:', error.message);
    return null;
  }

  return data ? toChatRoom(data as ChatRoomRow) : null;
}

export async function uploadChatImage(
  uri: string,
  userId: string,
  mimeType?: string | null,
): Promise<string> {
  return uploadImageToBucket({
    bucket: 'chat-images',
    uri,
    userId,
    mimeType,
  });
}

export async function uploadProfileAvatar(
  uri: string,
  userId: string,
  mimeType?: string | null,
): Promise<string> {
  return uploadImageToBucket({
    bucket: 'avatars',
    uri,
    userId,
    mimeType,
  });
}

export async function uploadListingImage(
  uri: string,
  userId: string,
  mimeType?: string | null,
): Promise<string> {
  return uploadImageToBucket({
    bucket: 'listing-images',
    uri,
    userId,
    mimeType,
  });
}

async function uploadImageToBucket({
  bucket,
  uri,
  userId,
  mimeType,
}: {
  bucket: 'chat-images' | 'avatars' | 'listing-images';
  uri: string;
  userId: string;
  mimeType?: string | null;
}): Promise<string> {
  const db = requireSupabase();
  const normalizedMime = mimeType || 'image/jpeg';
  let bytes: Uint8Array;

  try {
    // Works in web (blob/http/https) and some native URIs.
    const response = await fetch(uri);
    if (!response.ok) {
      throw new Error(`Failed to read image: ${response.status}`);
    }
    const arr = await response.arrayBuffer();
    bytes = new Uint8Array(arr);
  } catch {
    // Fallback for native file:// URIs.
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    bytes = Buffer.from(base64, 'base64');
  }

  const ext = normalizedMime.includes('png') ? 'png' : normalizedMime.includes('webp') ? 'webp' : 'jpg';
  const path = `${userId}/${Date.now()}-${genId()}.${ext}`;

  const { error: uploadError } = await db.storage
    .from(bucket)
    .upload(path, bytes, {
      contentType: normalizedMime,
      upsert: false,
    });

  if (uploadError) {
    throw new Error(uploadError.message);
  }

  const { data } = db.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}

export async function sendMessage(
  chatRoomId: string,
  senderId: string,
  text: string,
  imageUrl?: string | null,
): Promise<Message> {
  const db = requireSupabase();
  const authUserId = await requireAuthenticatedUserId();
  if (authUserId !== senderId) {
    throw new Error('You can send messages only as yourself');
  }
  await ensureUserCanAct(authUserId);

  const nowIso = new Date().toISOString();
  const normalizedText = text.trim();
  const normalizedImageUrl = imageUrl || null;
  if (!normalizedText && !normalizedImageUrl) {
    throw new Error('Message must contain text or image');
  }

  const { data, error } = await db
    .from('messages')
    .insert({
      chat_room_id: chatRoomId,
      sender_id: senderId,
      text: normalizedText || null,
      image_url: normalizedImageUrl,
    })
    .select('id, chat_room_id, sender_id, text, image_url, created_at')
    .single();

  if (error || !data) {
    throw new Error(error?.message || 'Failed to send message');
  }

  await db
    .from('chat_rooms')
    .update({ last_message_at: nowIso })
    .eq('id', chatRoomId);

  return toMessage(data as MessageRow);
}

export async function getChatMessages(chatRoomId: string): Promise<Message[]> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('messages')
    .select('id, chat_room_id, sender_id, text, image_url, created_at')
    .eq('chat_room_id', chatRoomId)
    .order('created_at', { ascending: true });

  if (error || !data) {
    console.error('Failed to load chat messages:', error?.message);
    return [];
  }

  return (data as MessageRow[]).map(toMessage);
}

export async function getLastMessage(chatRoomId: string): Promise<Message | null> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('messages')
    .select('id, chat_room_id, sender_id, text, image_url, created_at')
    .eq('chat_room_id', chatRoomId)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error('Failed to load last message:', error.message);
    return null;
  }

  return data ? toMessage(data as MessageRow) : null;
}

export async function proposeDeal(chatRoomId: string, listingId: string, proposedBy: string, userAId: string, userBId: string): Promise<Deal> {
  const db = requireSupabase();
  const authUserId = await requireAuthenticatedUserId();
  if (authUserId !== proposedBy) {
    throw new Error('You can propose deals only as yourself');
  }
  await ensureUserCanAct(authUserId);

  const [leftId, rightId] = sortUserPair(userAId, userBId);
  const { data, error } = await db
    .from('deals')
    .insert({
      listing_id: listingId,
      chat_room_id: chatRoomId,
      proposed_by: proposedBy,
      user_a_id: leftId,
      user_b_id: rightId,
      status: 'proposed',
    })
    .select('id, listing_id, chat_room_id, proposed_by, user_a_id, user_b_id, status, created_at')
    .single();

  if (error || !data) {
    throw new Error(error?.message || 'Failed to propose deal');
  }

  return toDeal(data as DealRow);
}

export async function confirmDeal(dealId: string): Promise<Deal | null> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('deals')
    .update({ status: 'confirmed' })
    .eq('id', dealId)
    .select('id, listing_id, chat_room_id, proposed_by, user_a_id, user_b_id, status, created_at')
    .maybeSingle();

  if (error) {
    throw new Error(error.message);
  }
  if (!data) {
    return null;
  }

  await db
    .from('listings')
    .update({ status: 'closed' })
    .eq('id', (data as DealRow).listing_id);

  return toDeal(data as DealRow);
}

export async function cancelDeal(dealId: string): Promise<Deal | null> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('deals')
    .update({ status: 'canceled' })
    .eq('id', dealId)
    .select('id, listing_id, chat_room_id, proposed_by, user_a_id, user_b_id, status, created_at')
    .maybeSingle();

  if (error) {
    throw new Error(error.message);
  }

  return data ? toDeal(data as DealRow) : null;
}

export async function getDealForChat(chatRoomId: string): Promise<Deal | null> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('deals')
    .select('id, listing_id, chat_room_id, proposed_by, user_a_id, user_b_id, status, created_at')
    .eq('chat_room_id', chatRoomId)
    .neq('status', 'canceled')
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error('Failed to load deal for chat:', error.message);
    return null;
  }

  return data ? toDeal(data as DealRow) : null;
}

export async function getUserDeals(userId: string): Promise<Deal[]> {
  const db = requireSupabase();
  const [left, right] = await Promise.all([
    db
      .from('deals')
      .select('id, listing_id, chat_room_id, proposed_by, user_a_id, user_b_id, status, created_at')
      .eq('user_a_id', userId),
    db
      .from('deals')
      .select('id, listing_id, chat_room_id, proposed_by, user_a_id, user_b_id, status, created_at')
      .eq('user_b_id', userId),
  ]);

  if (left.error || right.error) {
    console.error('Failed to load user deals:', left.error?.message || right.error?.message);
    return [];
  }

  const map = new Map<string, Deal>();
  for (const row of [...(left.data || []), ...(right.data || [])] as DealRow[]) {
    map.set(row.id, toDeal(row));
  }

  return Array.from(map.values()).sort((a, b) => b.createdAt - a.createdAt);
}

export function subscribeToListings(onChange: (payload?: any) => void) {
  const db = supabase;
  if (!db) return () => {};
  const channel = db
    .channel(`listings-feed-${genId()}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'listings' }, onChange)
    .subscribe();

  return () => {
    db.removeChannel(channel);
  };
}

export function subscribeToUserChats(userId: string, onChange: (payload?: any) => void) {
  const db = supabase;
  if (!db) return () => {};
  const channel = db
    .channel(`user-chats-${userId}-${genId()}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_rooms', filter: `user_a_id=eq.${userId}` }, onChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_rooms', filter: `user_b_id=eq.${userId}` }, onChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, onChange)
    .subscribe();

  return () => {
    db.removeChannel(channel);
  };
}

export function subscribeToChatRoom(chatRoomId: string, onChange: (payload?: any) => void) {
  const db = supabase;
  if (!db) return () => {};
  const channel = db
    .channel(`chat-room-${chatRoomId}-${genId()}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `chat_room_id=eq.${chatRoomId}` }, onChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'deals', filter: `chat_room_id=eq.${chatRoomId}` }, onChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_rooms', filter: `id=eq.${chatRoomId}` }, onChange)
    .subscribe();

  return () => {
    db.removeChannel(channel);
  };
}

export async function createReview(data: {
  dealId: string;
  fromUserId: string;
  toUserId: string;
  rating: number;
  text: string;
}): Promise<Review | { error: string }> {
  const db = requireSupabase();
  if (data.fromUserId === data.toUserId) {
    return { error: 'Cannot review yourself' };
  }
  if (data.rating < 1 || data.rating > 5) {
    return { error: 'Rating must be from 1 to 5' };
  }

  const { data: deal, error: dealError } = await db
    .from('deals')
    .select('id, status')
    .eq('id', data.dealId)
    .maybeSingle();

  if (dealError) {
    return { error: dealError.message };
  }
  if (!deal || deal.status !== 'confirmed') {
    return { error: 'Deal must be confirmed' };
  }

  const { data: existing, error: existingError } = await db
    .from('reviews')
    .select('id')
    .eq('deal_id', data.dealId)
    .eq('from_user_id', data.fromUserId)
    .maybeSingle();

  if (existingError) {
    return { error: existingError.message };
  }
  if (existing) {
    return { error: 'Already reviewed this deal' };
  }

  const { data: created, error: createError } = await db
    .from('reviews')
    .insert({
      deal_id: data.dealId,
      from_user_id: data.fromUserId,
      to_user_id: data.toUserId,
      rating: data.rating,
      text: data.text.trim(),
    })
    .select('id, deal_id, from_user_id, to_user_id, rating, text, created_at')
    .single();

  if (createError || !created) {
    return { error: createError?.message || 'Failed to create review' };
  }

  return toReview(created as ReviewRow);
}

export async function getUserReviews(userId: string): Promise<Review[]> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('reviews')
    .select('id, deal_id, from_user_id, to_user_id, rating, text, created_at')
    .eq('to_user_id', userId)
    .order('created_at', { ascending: false });

  if (error || !data) {
    console.error('Failed to load user reviews:', error?.message);
    return [];
  }

  return (data as ReviewRow[]).map(toReview);
}

export async function getReviewForDeal(dealId: string, fromUserId: string): Promise<Review | null> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('reviews')
    .select('id, deal_id, from_user_id, to_user_id, rating, text, created_at')
    .eq('deal_id', dealId)
    .eq('from_user_id', fromUserId)
    .maybeSingle();

  if (error) {
    console.error('Failed to load review for deal:', error.message);
    return null;
  }

  return data ? toReview(data as ReviewRow) : null;
}

export async function getUserRating(userId: string): Promise<{ average: number; count: number }> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('reviews')
    .select('rating')
    .eq('to_user_id', userId);

  if (error || !data) {
    console.error('Failed to load user rating:', error?.message);
    return { average: 0, count: 0 };
  }

  if (data.length === 0) return { average: 0, count: 0 };
  const sum = data.reduce((acc, r) => acc + Number(r.rating), 0);
  return { average: sum / data.length, count: data.length };
}

export async function createComplaint(data: {
  fromUserId: string;
  targetType: 'listing' | 'user';
  targetId: string;
  reason: string;
  description: string;
}): Promise<Complaint> {
  const db = requireSupabase();
  const { data: authData, error: authError } = await db.auth.getUser();
  if (authError || !authData.user) {
    throw new Error('You must be signed in to submit a report');
  }
  await ensureUserCanAct(authData.user.id);
  const { data: created, error } = await db
    .from('complaints')
    .insert({
      from_user_id: authData.user.id,
      target_type: data.targetType,
      target_id: data.targetId,
      reason: data.reason,
      description: data.description,
      status: 'new',
    })
    .select(COMPLAINT_SELECT)
    .single();

  if (error || !created) {
    throw new Error(error?.message || 'Failed to create complaint');
  }

  return toComplaint(created as ComplaintRow);
}

export type AdminUsersFilter = {
  status?: 'all' | UserStatus;
  search?: string;
};

export type AdminListingsFilter = {
  status?: 'all' | ListingStatus;
  search?: string;
  authorId?: string;
};

export type AdminComplaintItem = {
  complaint: Complaint;
  reporter: User | null;
  targetUser: User | null;
  targetListing: Listing | null;
  targetComplaintsCount: number;
};

export type AdminUserDetails = {
  user: User;
  listings: Listing[];
  complaintsCount: number;
  rating: { average: number; count: number };
  activeDeals: number;
};

export type AdminListingDetails = {
  listing: Listing;
  author: User | null;
  complaintsCount: number;
};

export type ComplaintDecision = 'delete_listing' | 'block_listing' | 'ban_user' | 'delete_user' | 'reject';

function filterUsersBySearch(users: User[], search?: string): User[] {
  const q = (search || '').trim().toLowerCase();
  if (!q) return users;
  return users.filter((user) =>
    user.username.toLowerCase().includes(q)
    || user.displayName.toLowerCase().includes(q)
    || user.id.toLowerCase().includes(q)
  );
}

function filterListingsBySearch(listings: Listing[], search?: string): Listing[] {
  const q = (search || '').trim().toLowerCase();
  if (!q) return listings;
  return listings.filter((listing) =>
    listing.id.toLowerCase().includes(q)
    || listing.title.toLowerCase().includes(q)
    || listing.description.toLowerCase().includes(q)
    || listing.category.toLowerCase().includes(q)
  );
}

export async function getAdminUsers(filter: AdminUsersFilter = {}): Promise<User[]> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('profiles')
    .select(PROFILE_SELECT)
    .order('created_at', { ascending: false })
    .limit(500);

  if (error || !data) {
    throw new Error(error?.message || 'Failed to load users');
  }

  let users = (data as ProfileRow[]).map(toUser);
  if (filter.status && filter.status !== 'all') {
    users = users.filter((u) => u.status === filter.status);
  }

  return filterUsersBySearch(users, filter.search);
}

export async function getAdminListings(filter: AdminListingsFilter = {}): Promise<Listing[]> {
  const db = requireSupabase();
  let query = db
    .from('listings')
    .select('id, author_id, type, title, description, photos, category, offering, want_in_return, status, created_at')
    .order('created_at', { ascending: false })
    .limit(500);

  if (filter.status && filter.status !== 'all') {
    query = query.eq('status', filter.status);
  }
  if (filter.authorId) {
    query = query.eq('author_id', filter.authorId);
  }

  const { data, error } = await query;
  if (error || !data) {
    throw new Error(error?.message || 'Failed to load listings');
  }

  const listings = (data as ListingRow[]).map(toListing);
  return filterListingsBySearch(listings, filter.search);
}

export async function getAdminUserDetails(userId: string): Promise<AdminUserDetails | null> {
  const [user, listings, rating, complaints, deals] = await Promise.all([
    getUser(userId),
    getAdminListings({ authorId: userId, status: 'all' }),
    getUserRating(userId),
    requireSupabase()
      .from('complaints')
      .select('id')
      .eq('target_type', 'user')
      .eq('target_id', userId),
    getUserDeals(userId),
  ]);

  if (!user) {
    return null;
  }

  const activeDeals = deals.filter((d) => d.status !== 'canceled').length;
  return {
    user,
    listings,
    complaintsCount: complaints.data?.length || 0,
    rating,
    activeDeals,
  };
}

export async function getAdminListingDetails(listingId: string): Promise<AdminListingDetails | null> {
  const listing = await getListing(listingId);
  if (!listing) {
    return null;
  }

  const [author, complaints] = await Promise.all([
    getUser(listing.authorId),
    requireSupabase()
      .from('complaints')
      .select('id')
      .eq('target_type', 'listing')
      .eq('target_id', listingId),
  ]);

  return {
    listing,
    author,
    complaintsCount: complaints.data?.length || 0,
  };
}

export async function getAdminComplaints(): Promise<AdminComplaintItem[]> {
  const db = requireSupabase();
  const { data: rows, error } = await db
    .from('complaints')
    .select(COMPLAINT_SELECT)
    .order('created_at', { ascending: false });

  if (error || !rows) {
    throw new Error(error?.message || 'Failed to load complaints');
  }

  const complaints = (rows as ComplaintRow[]).map(toComplaint);
  const targetCounts = new Map<string, number>();
  complaints.forEach((item) => {
    const key = `${item.targetType}:${item.targetId}`;
    targetCounts.set(key, (targetCounts.get(key) || 0) + 1);
  });

  return Promise.all(complaints.map(async (complaint) => {
    const [reporter, targetUser, targetListing] = await Promise.all([
      getUser(complaint.fromUserId),
      complaint.targetType === 'user' ? getUser(complaint.targetId) : Promise.resolve(null),
      complaint.targetType === 'listing' ? getListing(complaint.targetId) : Promise.resolve(null),
    ]);
    return {
      complaint,
      reporter,
      targetUser,
      targetListing,
      targetComplaintsCount: targetCounts.get(`${complaint.targetType}:${complaint.targetId}`) || 0,
    };
  }));
}

export async function setComplaintStatus(
  complaintId: string,
  status: 'new' | 'in_review' | 'resolved' | 'rejected',
  resolutionNote?: string,
): Promise<void> {
  const db = requireSupabase();
  const { error } = await db
    .rpc('admin_set_complaint_status', {
      p_complaint_id: complaintId,
      p_status: status,
      p_resolution_note: resolutionNote || null,
    });

  if (error) {
    throw new Error(error.message);
  }
}

export async function adminSetUserStatus(userId: string, status: UserStatus, reason?: string): Promise<void> {
  const db = requireSupabase();
  const { error } = await db.rpc('admin_set_user_status', {
    p_user_id: userId,
    p_status: status,
    p_reason: reason || null,
  });

  if (error) {
    throw new Error(error.message);
  }
}

export async function adminSetListingStatus(listingId: string, status: ListingStatus, reason?: string): Promise<void> {
  const db = requireSupabase();
  const { error } = await db.rpc('admin_set_listing_status', {
    p_listing_id: listingId,
    p_status: status,
    p_reason: reason || null,
  });

  if (error) {
    throw new Error(error.message);
  }
}

export async function adminResolveComplaint(complaintId: string, decision: ComplaintDecision, note?: string): Promise<void> {
  const db = requireSupabase();
  const { error } = await db.rpc('admin_resolve_complaint', {
    p_complaint_id: complaintId,
    p_decision: decision,
    p_note: note || null,
  });
  if (error) {
    throw new Error(error.message);
  }
}

export async function getAdminActionLogs(limit = 200): Promise<AdminActionLog[]> {
  const db = requireSupabase();
  const { data, error } = await db
    .from('admin_actions')
    .select('id, admin_id, target_type, target_id, action, details, created_at')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error || !data) {
    throw new Error(error?.message || 'Failed to load admin actions');
  }
  return (data as AdminActionRow[]).map(toAdminActionLog);
}

export async function adminBlockUser(userId: string, blocked: boolean): Promise<void> {
  await adminSetUserStatus(userId, blocked ? 'banned' : 'active');
}

export async function adminHideListing(listingId: string): Promise<void> {
  await adminSetListingStatus(listingId, 'deleted');
}
