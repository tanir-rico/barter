export type ListingType = 'book' | 'item' | 'service';
export type ListingStatus = 'active' | 'closed' | 'deleted' | 'blocked';
export type DealStatus = 'proposed' | 'confirmed' | 'canceled';
export type ComplaintTarget = 'listing' | 'user';
export type ComplaintStatus = 'new' | 'in_review' | 'resolved' | 'rejected';
export type UserStatus = 'active' | 'banned' | 'deleted';

export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  phone: string | null;
  bio: string;
  createdAt: number;
  blocked: boolean;
  isAdmin: boolean;
  status: UserStatus;
}

export interface Listing {
  id: string;
  authorId: string;
  type: ListingType;
  title: string;
  description: string;
  photos: string[];
  category: string;
  offering: string;
  wantInReturn: string;
  status: ListingStatus;
  createdAt: number;
}

export interface ChatRoom {
  id: string;
  listingId: string;
  userAId: string;
  userBId: string;
  createdAt: number;
  lastMessageAt: number;
}

export interface Message {
  id: string;
  chatRoomId: string;
  senderId: string;
  text: string;
  imageUrl?: string | null;
  createdAt: number;
}

export interface Deal {
  id: string;
  listingId: string;
  chatRoomId: string;
  proposedBy: string;
  userAId: string;
  userBId: string;
  status: DealStatus;
  createdAt: number;
}

export interface Review {
  id: string;
  dealId: string;
  fromUserId: string;
  toUserId: string;
  rating: number;
  text: string;
  createdAt: number;
}

export interface Complaint {
  id: string;
  fromUserId: string;
  targetType: ComplaintTarget;
  targetId: string;
  reason: string;
  description: string;
  status: ComplaintStatus;
  reviewedBy?: string | null;
  reviewedAt?: number | null;
  resolutionNote?: string | null;
  createdAt: number;
}

export interface AdminActionLog {
  id: string;
  adminId: string;
  targetType: 'user' | 'listing' | 'complaint';
  targetId: string;
  action: string;
  details: Record<string, unknown>;
  createdAt: number;
}

export const CATEGORIES = [
  'Fiction',
  'Non-Fiction',
  'Science',
  'Technology',
  'Art',
  'Music',
  'Sports',
  'Clothing',
  'Electronics',
  'Furniture',
  'Home & Garden',
  'Auto',
  'Games & Toys',
  'Pets',
  'Baby & Kids',
  'Health & Beauty',
  'Education',
  'Design',
  'Photography',
  'Cooking',
  'Languages',
  'Repair',
  'Collectibles',
  'Business',
  'Travel',
  'Other',
];
