# SwapHub

## Overview

SwapHub is a mobile barter platform (social exchange app) for trading books, items, and services. Users create listings describing what they offer and what they want in return, chat with other users about specific listings, propose and confirm deals, leave reviews, and file complaints. The app is built with Expo (React Native) for the frontend and Express for the backend, designed to run on iOS, Android, and web.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (Expo / React Native)

- **Framework**: Expo SDK 54 with expo-router for file-based routing
- **Navigation**: File-based routing using expo-router with tab navigation (`(tabs)/`), auth flow (`(auth)/`), and modal screens (listing create/edit, reviews, complaints)
- **State Management**: React Context API for global state (`DataContext` for user/auth data, `ThemeContext` for light/dark mode), local component state with `useState`, and `@tanstack/react-query` (available but most data currently loaded via direct storage calls)
- **Data Layer**: Currently uses AsyncStorage (`@react-native-async-storage/async-storage`) as the primary data store on the client side via `lib/storage.ts`. All CRUD operations for users, listings, chat rooms, messages, deals, reviews, and complaints happen through this local storage layer. The `lib/query-client.ts` file has API utilities ready for server communication but the app currently runs mostly client-side.
- **Styling**: Raw React Native StyleSheet (no UI library), with a custom theme system in `constants/colors.ts` supporting light and dark modes
- **Fonts**: Inter font family loaded via `@expo-google-fonts/inter`
- **Key Libraries**: expo-image, expo-image-picker, expo-haptics, react-native-gesture-handler, react-native-reanimated, react-native-keyboard-controller

### Authentication Flow

- Client-side auth using AsyncStorage - users register/login, credentials stored locally
- Password hashing done client-side via expo-crypto
- Auth state managed through `DataContext` which checks for stored user on app load
- Route protection via `_layout.tsx` that redirects unauthenticated users to login

### Backend (Express)

- **Server**: Express 5 running on Node.js (`server/index.ts`)
- **Routes**: Minimal - `server/routes.ts` creates an HTTP server but has no API routes implemented yet (placeholder for future API development)
- **Storage**: `server/storage.ts` has a `MemStorage` class implementing an `IStorage` interface with basic user CRUD. This is ready to be swapped for database-backed storage.
- **CORS**: Configured for Replit dev/deployment domains and localhost
- **Static serving**: In production, serves the Expo web build from `dist/`; in development, proxies to Metro bundler

### Database Schema (Drizzle + PostgreSQL)

- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema file**: `shared/schema.ts` - currently minimal with just a `users` table (id, username, password)
- **Validation**: drizzle-zod for generating Zod schemas from Drizzle table definitions
- **Migration**: Drizzle Kit configured via `drizzle.config.ts`, migrations output to `./migrations/`
- **Note**: The full data model (listings, chat rooms, messages, deals, reviews, complaints) exists as TypeScript types in `lib/types.ts` but has NOT been added to the Drizzle schema yet. The schema needs to be expanded to match these types.

### Key Data Types (defined in `lib/types.ts`)

- **User**: id, username, displayName, avatar, phone, bio, blocked status
- **Listing**: id, authorId, type (book/item/service), title, description, photos, category, offering, wantInReturn, status (active/closed/deleted)
- **ChatRoom**: id, listingId, userAId, userBId, timestamps
- **Message**: id, chatRoomId, senderId, text, timestamp
- **Deal**: proposed/confirmed/canceled between two users for a listing
- **Review**: rating + text for completed deals
- **Complaint**: targeting users or listings with reason and description

### App Screens

- **Auth**: Login, Register
- **Tabs**: Catalog (browse/search/filter listings), Chats (conversation list), Profile (user info, listings, reviews, deals)
- **Modals/Screens**: Listing detail, Create listing, Edit listing, Chat detail, User profile, Review submission, Complaint submission

### Build & Deployment

- Development: `expo:dev` for mobile, `server:dev` for Express backend
- Production: Expo static web build (`expo:static:build`) served by Express (`server:prod`)
- Server bundled with esbuild (`server:build`)

## External Dependencies

- **Database**: PostgreSQL (configured via `DATABASE_URL` environment variable, used by Drizzle Kit)
- **AsyncStorage**: Currently the primary data store (client-side), meant to be replaced/supplemented by server API + PostgreSQL
- **Expo Services**: Expo build and development tooling
- **No external APIs**: No third-party auth providers, payment systems, or external services currently integrated