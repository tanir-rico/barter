## Supabase Setup

1. Open Supabase SQL Editor and run `supabase/profiles.sql`.
2. Run `supabase/marketplace.sql`.
3. In Supabase Auth settings, disable mandatory email confirmation for local testing (optional, but recommended).
4. Create `.env` from `.env.example` and set:
   - `EXPO_PUBLIC_SUPABASE_URL`
   - `EXPO_PUBLIC_SUPABASE_ANON_KEY`
5. Restart Expo after updating env vars.
