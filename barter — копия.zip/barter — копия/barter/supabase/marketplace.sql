create extension if not exists pgcrypto;

alter table if exists public.profiles
add column if not exists is_admin boolean not null default false;

alter table if exists public.profiles
add column if not exists status text not null default 'active';

do $$
begin
  if to_regclass('public.profiles') is not null then
    alter table public.profiles drop constraint if exists profiles_status_check;
    alter table public.profiles
      add constraint profiles_status_check
      check (status in ('active', 'banned', 'deleted'));
  end if;
end
$$;

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('book', 'item', 'service')),
  title text not null,
  description text not null,
  photos jsonb not null default '[]'::jsonb,
  category text not null,
  offering text not null,
  want_in_return text not null,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

do $$
begin
  if to_regclass('public.listings') is not null then
    alter table public.listings drop constraint if exists listings_status_check;
    alter table public.listings
      add constraint listings_status_check
      check (status in ('active', 'closed', 'blocked', 'deleted'));
  end if;
end
$$;

create table if not exists public.chat_rooms (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  user_a_id uuid not null references public.profiles(id) on delete cascade,
  user_b_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now(),
  constraint chat_rooms_pair_unique unique (listing_id, user_a_id, user_b_id),
  constraint chat_rooms_diff_users check (user_a_id <> user_b_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  chat_room_id uuid not null references public.chat_rooms(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  text text,
  image_url text,
  created_at timestamptz not null default now()
);

alter table if exists public.messages add column if not exists image_url text;
alter table if exists public.messages alter column text drop not null;

create table if not exists public.deals (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  chat_room_id uuid not null references public.chat_rooms(id) on delete cascade,
  proposed_by uuid not null references public.profiles(id) on delete cascade,
  user_a_id uuid not null references public.profiles(id) on delete cascade,
  user_b_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'proposed' check (status in ('proposed', 'confirmed', 'canceled')),
  created_at timestamptz not null default now(),
  constraint deals_diff_users check (user_a_id <> user_b_id)
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  deal_id uuid not null references public.deals(id) on delete cascade,
  from_user_id uuid not null references public.profiles(id) on delete cascade,
  to_user_id uuid not null references public.profiles(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  text text not null default '',
  created_at timestamptz not null default now(),
  constraint reviews_one_per_deal_from_user unique (deal_id, from_user_id),
  constraint reviews_no_self check (from_user_id <> to_user_id)
);

create table if not exists public.complaints (
  id uuid primary key default gen_random_uuid(),
  from_user_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('listing', 'user')),
  target_id uuid not null,
  reason text not null,
  description text not null,
  status text not null default 'new',
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  resolution_note text,
  created_at timestamptz not null default now()
);

do $$
begin
  if to_regclass('public.complaints') is not null then
    alter table public.complaints drop constraint if exists complaints_status_check;
    alter table public.complaints
      add constraint complaints_status_check
      check (status in ('new', 'in_review', 'resolved', 'rejected'));
  end if;
end
$$;

create table if not exists public.admin_actions (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('user', 'listing', 'complaint')),
  target_id uuid not null,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists listings_author_id_idx on public.listings(author_id);
create index if not exists listings_status_idx on public.listings(status);
create index if not exists chat_rooms_user_a_id_idx on public.chat_rooms(user_a_id);
create index if not exists chat_rooms_user_b_id_idx on public.chat_rooms(user_b_id);
create index if not exists chat_rooms_listing_id_idx on public.chat_rooms(listing_id);
create index if not exists messages_chat_room_id_idx on public.messages(chat_room_id);
create index if not exists messages_created_at_idx on public.messages(created_at);
create index if not exists deals_chat_room_id_idx on public.deals(chat_room_id);
create index if not exists reviews_to_user_id_idx on public.reviews(to_user_id);
create index if not exists reviews_deal_id_idx on public.reviews(deal_id);
create index if not exists complaints_status_idx on public.complaints(status);
create index if not exists complaints_created_at_idx on public.complaints(created_at);
create index if not exists complaints_target_idx on public.complaints(target_type, target_id);
create index if not exists admin_actions_target_idx on public.admin_actions(target_type, target_id);
create index if not exists admin_actions_created_at_idx on public.admin_actions(created_at);

create or replace function public.is_admin(uid uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = uid
      and p.is_admin = true
      and p.status <> 'deleted'
  );
$$;

create or replace function public.is_active_user(uid uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = uid
      and p.status = 'active'
  );
$$;

revoke all on function public.is_admin(uuid) from public;
revoke all on function public.is_active_user(uuid) from public;
grant execute on function public.is_admin(uuid) to anon, authenticated;
grant execute on function public.is_active_user(uuid) to anon, authenticated;

create or replace function public.profiles_guard_trigger()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'UPDATE' and not public.is_admin(auth.uid()) then
    if old.status is distinct from new.status
      or old.is_admin is distinct from new.is_admin
      or old.blocked is distinct from new.blocked then
      raise exception 'Only admins can change sensitive profile fields';
    end if;
  end if;

  if new.status = 'banned' then
    new.blocked := true;
  elsif new.status in ('active', 'deleted') then
    new.blocked := false;
  end if;

  return new;
end
$$;

drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard
before insert or update on public.profiles
for each row
execute function public.profiles_guard_trigger();

alter table public.listings enable row level security;
alter table public.chat_rooms enable row level security;
alter table public.messages enable row level security;
alter table public.deals enable row level security;
alter table public.reviews enable row level security;
alter table public.complaints enable row level security;
alter table public.admin_actions enable row level security;
alter table public.profiles enable row level security;

drop policy if exists "profiles_select_visible" on public.profiles;
create policy "profiles_select_visible"
on public.profiles
for select
using (
  public.is_admin(auth.uid())
  or auth.uid() = id
  or status <> 'deleted'
);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own"
on public.profiles
for insert
with check (auth.uid() = id and status = 'active');

drop policy if exists "profiles_update_own_non_sensitive" on public.profiles;
create policy "profiles_update_own_non_sensitive"
on public.profiles
for update
using (auth.uid() = id and status <> 'deleted')
with check (auth.uid() = id and status <> 'deleted');

drop policy if exists "profiles_update_admin" on public.profiles;
create policy "profiles_update_admin"
on public.profiles
for update
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));

drop policy if exists "listings_select_visible" on public.listings;
create policy "listings_select_visible"
on public.listings
for select
using (
  public.is_admin(auth.uid())
  or (
    status in ('active', 'closed')
    and exists (
      select 1
      from public.profiles p
      where p.id = listings.author_id
        and p.status <> 'deleted'
    )
  )
);

drop policy if exists "listings_insert_own_active" on public.listings;
create policy "listings_insert_own_active"
on public.listings
for insert
with check (
  auth.uid() = author_id
  and public.is_active_user(auth.uid())
);

drop policy if exists "listings_update_owner_or_admin" on public.listings;
create policy "listings_update_owner_or_admin"
on public.listings
for update
using (
  public.is_admin(auth.uid())
  or (auth.uid() = author_id and public.is_active_user(auth.uid()))
)
with check (
  public.is_admin(auth.uid())
  or (auth.uid() = author_id and public.is_active_user(auth.uid()))
);

drop policy if exists "chat_rooms_select_participants_or_admin" on public.chat_rooms;
create policy "chat_rooms_select_participants_or_admin"
on public.chat_rooms
for select
using (
  public.is_admin(auth.uid())
  or auth.uid() in (user_a_id, user_b_id)
);

drop policy if exists "chat_rooms_insert_participant_active" on public.chat_rooms;
create policy "chat_rooms_insert_participant_active"
on public.chat_rooms
for insert
with check (
  auth.uid() in (user_a_id, user_b_id)
  and public.is_active_user(auth.uid())
);

drop policy if exists "chat_rooms_update_participants_active" on public.chat_rooms;
create policy "chat_rooms_update_participants_active"
on public.chat_rooms
for update
using (
  public.is_admin(auth.uid())
  or (auth.uid() in (user_a_id, user_b_id) and public.is_active_user(auth.uid()))
)
with check (
  public.is_admin(auth.uid())
  or (auth.uid() in (user_a_id, user_b_id) and public.is_active_user(auth.uid()))
);

drop policy if exists "messages_select_participants_or_admin" on public.messages;
create policy "messages_select_participants_or_admin"
on public.messages
for select
using (
  public.is_admin(auth.uid())
  or exists (
    select 1
    from public.chat_rooms cr
    where cr.id = messages.chat_room_id
      and auth.uid() in (cr.user_a_id, cr.user_b_id)
  )
);

drop policy if exists "messages_insert_sender_participant_active" on public.messages;
create policy "messages_insert_sender_participant_active"
on public.messages
for insert
with check (
  (coalesce(length(trim(text)), 0) > 0 or image_url is not null)
  and auth.uid() = sender_id
  and public.is_active_user(auth.uid())
  and exists (
    select 1
    from public.chat_rooms cr
    where cr.id = messages.chat_room_id
      and auth.uid() in (cr.user_a_id, cr.user_b_id)
  )
);

drop policy if exists "deals_select_participants_or_admin" on public.deals;
create policy "deals_select_participants_or_admin"
on public.deals
for select
using (
  public.is_admin(auth.uid())
  or auth.uid() in (user_a_id, user_b_id)
);

drop policy if exists "deals_insert_participants_active" on public.deals;
create policy "deals_insert_participants_active"
on public.deals
for insert
with check (
  auth.uid() in (user_a_id, user_b_id)
  and auth.uid() = proposed_by
  and public.is_active_user(auth.uid())
);

drop policy if exists "deals_update_participants_active" on public.deals;
create policy "deals_update_participants_active"
on public.deals
for update
using (
  public.is_admin(auth.uid())
  or (auth.uid() in (user_a_id, user_b_id) and public.is_active_user(auth.uid()))
)
with check (
  public.is_admin(auth.uid())
  or (auth.uid() in (user_a_id, user_b_id) and public.is_active_user(auth.uid()))
);

drop policy if exists "reviews_select_all" on public.reviews;
create policy "reviews_select_all"
on public.reviews
for select
using (true);

drop policy if exists "reviews_insert_from_user_active" on public.reviews;
create policy "reviews_insert_from_user_active"
on public.reviews
for insert
with check (
  auth.uid() = from_user_id
  and public.is_active_user(auth.uid())
);

drop policy if exists "complaints_insert_own_active" on public.complaints;
create policy "complaints_insert_own_active"
on public.complaints
for insert
with check (
  auth.uid() = from_user_id
  and public.is_active_user(auth.uid())
);

drop policy if exists "complaints_select_own_or_admin" on public.complaints;
create policy "complaints_select_own_or_admin"
on public.complaints
for select
using (
  auth.uid() = from_user_id
  or public.is_admin(auth.uid())
);

drop policy if exists "complaints_update_admin" on public.complaints;
create policy "complaints_update_admin"
on public.complaints
for update
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));

drop policy if exists "admin_actions_select_admin" on public.admin_actions;
create policy "admin_actions_select_admin"
on public.admin_actions
for select
using (public.is_admin(auth.uid()));

drop policy if exists "admin_actions_insert_admin" on public.admin_actions;
create policy "admin_actions_insert_admin"
on public.admin_actions
for insert
with check (public.is_admin(auth.uid()) and auth.uid() = admin_id);

create or replace function public.admin_set_user_status(
  p_user_id uuid,
  p_status text,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin(auth.uid()) then
    raise exception 'Only admins can change user status';
  end if;

  if p_status not in ('active', 'banned', 'deleted') then
    raise exception 'Invalid user status';
  end if;

  update public.profiles
  set status = p_status
  where id = p_user_id;

  if p_status = 'deleted' then
    update public.listings
    set status = 'deleted'
    where author_id = p_user_id
      and status <> 'deleted';
  end if;

  insert into public.admin_actions (admin_id, target_type, target_id, action, details)
  values (
    auth.uid(),
    'user',
    p_user_id,
    'set_user_status',
    jsonb_build_object('status', p_status, 'reason', p_reason)
  );
end
$$;

create or replace function public.admin_set_listing_status(
  p_listing_id uuid,
  p_status text,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin(auth.uid()) then
    raise exception 'Only admins can change listing status';
  end if;

  if p_status not in ('active', 'closed', 'blocked', 'deleted') then
    raise exception 'Invalid listing status';
  end if;

  update public.listings
  set status = p_status
  where id = p_listing_id;

  insert into public.admin_actions (admin_id, target_type, target_id, action, details)
  values (
    auth.uid(),
    'listing',
    p_listing_id,
    'set_listing_status',
    jsonb_build_object('status', p_status, 'reason', p_reason)
  );
end
$$;

create or replace function public.admin_set_complaint_status(
  p_complaint_id uuid,
  p_status text,
  p_resolution_note text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin(auth.uid()) then
    raise exception 'Only admins can update complaints';
  end if;

  if p_status not in ('new', 'in_review', 'resolved', 'rejected') then
    raise exception 'Invalid complaint status';
  end if;

  update public.complaints
  set status = p_status,
      reviewed_by = auth.uid(),
      reviewed_at = now(),
      resolution_note = p_resolution_note
  where id = p_complaint_id;

  insert into public.admin_actions (admin_id, target_type, target_id, action, details)
  values (
    auth.uid(),
    'complaint',
    p_complaint_id,
    'set_complaint_status',
    jsonb_build_object('status', p_status, 'note', p_resolution_note)
  );
end
$$;

create or replace function public.admin_resolve_complaint(
  p_complaint_id uuid,
  p_decision text,
  p_note text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_complaint public.complaints%rowtype;
  v_status text;
begin
  if not public.is_admin(auth.uid()) then
    raise exception 'Only admins can resolve complaints';
  end if;

  select *
  into v_complaint
  from public.complaints
  where id = p_complaint_id;

  if not found then
    raise exception 'Complaint not found';
  end if;

  if v_complaint.target_type = 'listing' then
    if p_decision = 'delete_listing' then
      perform public.admin_set_listing_status(v_complaint.target_id, 'deleted', p_note);
      v_status := 'resolved';
    elsif p_decision = 'block_listing' then
      perform public.admin_set_listing_status(v_complaint.target_id, 'blocked', p_note);
      v_status := 'resolved';
    elsif p_decision = 'reject' then
      v_status := 'rejected';
    else
      raise exception 'Invalid decision for listing complaint';
    end if;
  elsif v_complaint.target_type = 'user' then
    if p_decision = 'ban_user' then
      perform public.admin_set_user_status(v_complaint.target_id, 'banned', p_note);
      v_status := 'resolved';
    elsif p_decision = 'delete_user' then
      perform public.admin_set_user_status(v_complaint.target_id, 'deleted', p_note);
      v_status := 'resolved';
    elsif p_decision = 'reject' then
      v_status := 'rejected';
    else
      raise exception 'Invalid decision for user complaint';
    end if;
  else
    raise exception 'Unsupported complaint target type';
  end if;

  update public.complaints
  set status = v_status,
      reviewed_by = auth.uid(),
      reviewed_at = now(),
      resolution_note = p_note
  where id = p_complaint_id;

  insert into public.admin_actions (admin_id, target_type, target_id, action, details)
  values (
    auth.uid(),
    'complaint',
    p_complaint_id,
    'resolve_complaint',
    jsonb_build_object('decision', p_decision, 'status', v_status, 'note', p_note)
  );
end
$$;

revoke all on function public.admin_set_user_status(uuid, text, text) from public;
revoke all on function public.admin_set_listing_status(uuid, text, text) from public;
revoke all on function public.admin_set_complaint_status(uuid, text, text) from public;
revoke all on function public.admin_resolve_complaint(uuid, text, text) from public;
grant execute on function public.admin_set_user_status(uuid, text, text) to authenticated;
grant execute on function public.admin_set_listing_status(uuid, text, text) to authenticated;
grant execute on function public.admin_set_complaint_status(uuid, text, text) to authenticated;
grant execute on function public.admin_resolve_complaint(uuid, text, text) to authenticated;

insert into storage.buckets (id, name, public)
values ('chat-images', 'chat-images', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('listing-images', 'listing-images', true)
on conflict (id) do nothing;

drop policy if exists "chat_images_public_read" on storage.objects;
create policy "chat_images_public_read"
on storage.objects
for select
using (bucket_id = 'chat-images');

drop policy if exists "chat_images_insert_own" on storage.objects;
create policy "chat_images_insert_own"
on storage.objects
for insert
with check (
  bucket_id = 'chat-images'
  and auth.uid()::text = (storage.foldername(name))[1]
  and public.is_active_user(auth.uid())
);

drop policy if exists "avatars_public_read" on storage.objects;
create policy "avatars_public_read"
on storage.objects
for select
using (bucket_id = 'avatars');

drop policy if exists "avatars_insert_own" on storage.objects;
create policy "avatars_insert_own"
on storage.objects
for insert
with check (
  bucket_id = 'avatars'
  and auth.uid()::text = (storage.foldername(name))[1]
  and public.is_active_user(auth.uid())
);

drop policy if exists "listing_images_public_read" on storage.objects;
create policy "listing_images_public_read"
on storage.objects
for select
using (bucket_id = 'listing-images');

drop policy if exists "listing_images_insert_own" on storage.objects;
create policy "listing_images_insert_own"
on storage.objects
for insert
with check (
  bucket_id = 'listing-images'
  and auth.uid()::text = (storage.foldername(name))[1]
  and public.is_active_user(auth.uid())
);

do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'listings'
  ) then
    alter publication supabase_realtime add table public.listings;
  end if;

  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'chat_rooms'
  ) then
    alter publication supabase_realtime add table public.chat_rooms;
  end if;

  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'messages'
  ) then
    alter publication supabase_realtime add table public.messages;
  end if;

  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'deals'
  ) then
    alter publication supabase_realtime add table public.deals;
  end if;

  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'complaints'
  ) then
    alter publication supabase_realtime add table public.complaints;
  end if;
end
$$;
