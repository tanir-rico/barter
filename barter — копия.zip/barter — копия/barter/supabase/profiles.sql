create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  display_name text not null,
  avatar text,
  phone text,
  bio text not null default '',
  blocked boolean not null default false,
  is_admin boolean not null default false,
  status text not null default 'active' check (status in ('active', 'banned', 'deleted')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "profiles_select_visible" on public.profiles;
create policy "profiles_select_visible"
on public.profiles
for select
using (
  auth.uid() = id
  or status <> 'deleted'
);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own"
on public.profiles
for insert
with check (auth.uid() = id and status = 'active');

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
on public.profiles
for update
using (auth.uid() = id and status <> 'deleted')
with check (auth.uid() = id and status <> 'deleted');
